#define ROS
#ifdef ROS
#include "ros/ros.h"
#include "auto_knight/Tachometer.h"
#endif
#include "tachometer.h"

#define ROTATIONS 13

float checkRPM();
int main(int argc, char** argv)
{
#ifdef ROS
 ros::init(argc, argv, "tachometer");
 ros::NodeHandle n;
 ros::Publisher pub = n.advertise<auto_knight::Tachometer>("/tachometer", 1);
#endif
 int __COUNTS__ = 5;
 if(argc > 1)
  __COUNTS__ = atoi(argv[1]);
 int __SPEED__ = 2000;
 if(argc > 2)
  __SPEED__ = atoi(argv[2]);
 printf("This iteration's\nCounts=%d\nSpeed=%d\n", __COUNTS__, __SPEED__);
 if(FILE* pin_exists = fopen(SYS_FS_LOCATION, "r"))
 {
  fclose(pin_exists);

#ifdef GPIO
  gpioUnexport(TACHOMETER);
#endif
 }
#ifdef GPIO
 gpioExport(TACHOMETER);
 gpioSetDirection(TACHOMETER, 0);
#endif
 double total_rpm = 0.0;
 double amount = 0;
 unsigned int num_zeros = 0;
 unsigned int count = 0;
 unsigned edges[2] = {0, 0};
 gpioGetValue(TACHOMETER, &edges[0]);
 initTimer();
 char buffers[3][128];
 sprintf(buffers[0], "files/tachs_counts_%d_speed_%d.txt", __COUNTS__, __SPEED__);
 sprintf(buffers[1], "files/times_counts_%d_speed_%d.txt",__COUNTS__,  __SPEED__);
 sprintf(buffers[2], "files/raw_2000.txt");

 printf("Files:\n\'%s\'\n\'%s\'\n", buffers[0], buffers[1]);
 FILE* tachs = fopen(buffers[0], "w");
 FILE* times = fopen(buffers[1], "w");
 FILE* raw = fopen(buffers[2], "w");
#ifdef GPIO
 int value = 1;
 while(value)
 {
  scanf("%d", &value);
 }
#endif
 double last_time = 0, time = 0;
#ifdef ROS
 while(ros::ok())
 {
  while(ros::ok() && count < __COUNTS__ && time < 1000)
  {
   edges[1] = edges[0];
   while(ros::ok() && edges[1] == edges[0])
   {
    gpioGetValue(TACHOMETER, &edges[0]);
    if(edges[0] != edges[1])
    {
     time = millis() - last_time;
     printf("%d @ %lf ms\n", edges[0], time);
     count++;
    }
   }
  }

  time = millis() - last_time;
  last_time = millis();
  double rpm = (count*30000)/time;

  auto_knight::Tachometer msg;
  msg.rpm = rpm;
  pub.publish(msg);

  fprintf(tachs, "%lf\n", rpm);
  fprintf(times, "%lf\n", time);
  count = 0;
  ros::spinOnce();
 }
 fclose(tachs);
 fclose(times);
 fclose(raw);
#endif
#ifdef GPIO
 gpioUnexport(TACHOMETER);
#endif
 return 0;
}
