#include "tachometer.h"

int main(int argc, char** argv)
{
 if(FILE* pin_exists = fopen(SYS_FS_LOCATION, "r"))
 {
  fclose(pin_exists);

  gpioUnexport(TACHOMETER);
 }

 gpioExport(TACHOMETER);
 gpioSetDirection(TACHOMETER, 0);

 int value = 1;
 while(value)
 {
  scanf("%d", &value);
 }
 gpioUnexport(TACHOMETER);
 return 0;
}
