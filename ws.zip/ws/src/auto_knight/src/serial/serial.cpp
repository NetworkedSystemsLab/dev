#include "ros/ros.h"
#include "auto_knight/Telemetry.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <time.h>
//#include <curses.h>

#define TelemetryPtr auto_knight::Telemetry::ConstPtr

#define THROTTLE_FULL_REVERSE 1000
#define THROTTLE_NEUTRAL 1600
#define THROTTLE_FULL_FORWARD 2000

#define STEERING_FULL_LEFT 60
#define STEERING_NEUTRAL 90
#define STEERING_FULL_RIGHT 120

int open_port(void);
int configure_port(int* fd);
void zeroize(int fd);

int port;

void serialCallback(const TelemetryPtr& msg)
{
 int speed = msg->speed;
 int angle = msg->angle;

 speed = (THROTTLE_FULL_REVERSE <= speed && speed <= THROTTLE_FULL_FORWARD) ? speed : THROTTLE_NEUTRAL;
 angle = (STEERING_FULL_LEFT <= angle && angle <= STEERING_FULL_RIGHT) ? angle : STEERING_NEUTRAL;

 static char last_bytes[2] = {-1, 1};
 char bytes[2] = {(speed - 1000)/10, -(char)angle};

 if(bytes[0] != last_bytes[0])
 {
  last_bytes[0] = bytes[0];
  write(port, &bytes[0], 1);
 }

 if(bytes[1] != last_bytes[1])
 {
  last_bytes[1] = bytes[1];
  write(port, &bytes[1], 1);
 }

 printf("\rThrottle = %4d; Steering = %3d", speed, angle);
}

int main(int argc, char** argv)
{
 //get the arduino variable
 int ttyACM0 = open_port();
 configure_port( &ttyACM0 );
 port = ttyACM0;

 ros::init(argc, argv, "serialReader");
 ros::NodeHandle nh;

 ros::Subscriber sub = nh.subscribe("/serial", 1, serialCallback);

 //initscr();
 //cbreak();
 if(argc > 1)
 {
  //timeout(atoi(argv[1]));
 }// else {
 //timeout(1);}
 //noecho();
 ros::spin();
 //endwin();

 zeroize(port);

 return 0;
}

int open_port(void)
{
 int fd = open("/dev/ttyACM0", O_RDWR | O_NOCTTY | O_NDELAY);
 if(fd != -1)
 {
  fcntl(fd, F_SETFL, 0);
  printf("/dev/ttyACM0 is selected.\n");
 }
 return fd;
}
int configure_port(int* fd)
{
 struct termios ps; //port settings
 cfsetispeed( &ps, B9600 ); //9600 input baud rate
 cfsetospeed( &ps, B9600 ); //9600 output baud rate

 ps.c_cflag &= ~PARENB;
 ps.c_cflag &= ~CSTOPB;
 ps.c_cflag &= ~CSIZE;
 ps.c_cflag |= CS8;

 tcsetattr( *fd, TCSANOW, &ps );
 return *fd;
}
void zeroize( int fd )
{
 char byte[2] = { 60, -90 };
 write( fd, &byte[0], 1);
 write( fd, &byte[1], 1);
}

