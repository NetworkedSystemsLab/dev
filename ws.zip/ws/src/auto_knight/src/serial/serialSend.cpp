#include "ros/ros.h"
#include "auto_knight/Telemetry.h"
#include <pthread.h>

void* checkInput(void* args)
{
 int* RUNNING = (int*)args;
 while(RUNNING[2])
 {
  char c;
  scanf("%c", &c);
  if(c == 't')
  {
   scanf("%d", &RUNNING[0]);
  } else if(c == 's') {
   scanf("%d", &RUNNING[1]);
  } else {
   scanf("%d", &RUNNING[2]);
  }
 }
 pthread_exit(NULL);
}

int main(int argc, char** argv)
{
 int vals[3] = {1600, 90, 1};
 pthread_t thread;
 pthread_create(&thread, NULL, checkInput, vals);

 ros::init(argc, argv, "serial_writer");
 ros::NodeHandle nh;
 ros::Publisher pub = nh.advertise<auto_knight::Telemetry>("serial", 10);
 ros::Rate loop_rate(10);
 while(ros::ok() && vals[2])
 {
  auto_knight::Telemetry msg;
  msg.speed = vals[0];
  msg.angle = vals[1];
  pub.publish(msg);
  ros::spinOnce();
  loop_rate.sleep();
 }

 pthread_exit(NULL);
}
