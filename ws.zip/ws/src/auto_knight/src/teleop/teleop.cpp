#include "ros/ros.h"
#include "auto_knight/Telemetry.h"
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <curses.h>

struct timeval timer_angle_begin, timer_speed_begin, timer_angle_end, timer_speed_end;
#define initTimer(begin)\
	gettimeofday(&begin, NULL)
int millis(struct timeval begin, struct timeval end)
{
	gettimeofday(&end, NULL);
	return ((end.tv_sec - begin.tv_sec) * 1000 + (end.tv_usec-begin.tv_usec)/1000);
}

const char* header = "****************************************************************************\n******                    **Networked Systems Lab**                   ******\n******                     TeleOp V.1.0.1 Running                     ******            \n******                                                                ******             \n******                              |W|                               ******             \n******                                                                ******             \n******       Hard Left: |Q|    |A|  |S|  |D|    Hard Right: |E|       ******             \n******                                                                ******             \n******                         |B|       |P|                          ******             \n******                        Brake      Park                         ******\n";
const char* footer = "****************************************************************************               \nPress \"0\" to Terminate\n               \nTeleOp by: Behrad Toghi, Christian Theriot - NSL               \n**************************************************************************** \n\n";

int main(int argc, char** argv)
{
 ros::init(argc, argv, "serialWriter");
 ros::NodeHandle nh;

 ros::Publisher pub = nh.advertise<auto_knight::Telemetry>("/serial", 1);
 int angle_step = 1;
 int speed_step = 1;
 if(argc > 1)
 {
  speed_step = atoi(argv[1]);
 }
 if(argc > 2)
 {
  angle_step = atoi(argv[2]);
 }
 int speed = 1600;
 int angle = 90;

 initscr();
 cbreak();
 timeout(500);
 noecho();
 printw("%s", header);
 printw("%s", footer);
 bool set_speed = false;
 bool set_angle = false;

 char c = 'p';
 while(ros::ok())
 {
  auto_knight::Telemetry msg;
	c = getch();

        if(set_angle && millis(timer_angle_begin, timer_angle_end) > 100)
	{
         set_angle = false;
	 angle = 90;
 	}
        if(set_speed && millis(timer_speed_begin, timer_speed_end) > 100)
	{
 	 set_speed = false;
	 speed = 1600;
	}

  switch(c)
  {
   case 'w':
	speed += speed_step;
        speed = speed > 2000 ? 2000 : speed;
	break;
   case 'a':
	angle -= angle_step;
        angle < 60 ? 60 : angle;
	break;
   case 's':
	speed -= speed_step;
        speed < 1000 ? 1000 : speed;
	break;
   case 'd':
	angle += angle_step;
        angle > 120 ? 120 : angle;
	break;
   case 'q':
        set_angle = true;
	angle = 60;
        initTimer(timer_angle_begin);
	break;
   case 'e':
        set_angle = true;
	angle = 120;
        initTimer(timer_angle_begin);
	break;
   case '0':
        msg.speed = 1600;
        msg.angle = 90;
        pub.publish(msg);
        endwin();
        return 0;
   case 'b':
        if(speed > 1600)
	{
 	 speed = 1000;
	} else if(speed < 1600) {
	 speed = 2000;
	}
        set_speed = true;
        initTimer(timer_speed_begin);
        angle = 90;
	break;
   case 'p':
        speed = 1600;
        angle = 90;
	break;
   default:
	break;
  }
  speed = 1000 <= speed && speed <= 2000 ? speed : 1600;
  angle = 60 <= angle && angle <= 120 ? angle : 90;

  printw("\rThrottle = %4d, Steering = %3d", speed, angle);

  msg.speed = speed;
  msg.angle = angle;
  pub.publish(msg);  

 }
 endwin();
 return 0;
}
