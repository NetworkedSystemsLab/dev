
"use strict";

let Tachometer = require('./Tachometer.js');
let Telemetry = require('./Telemetry.js');

module.exports = {
  Tachometer: Tachometer,
  Telemetry: Telemetry,
};
