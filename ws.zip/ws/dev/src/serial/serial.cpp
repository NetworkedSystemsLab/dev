#include "serial.h"
#include <stdlib.h>
#include <string.h>
#include <sched.h>

void zeroize(int fd)
{
char n_sync0 = HEADER_BYTE, n_sync1 = TRAILER_BYTE, n_s=-90, n_m=60;
// write(fd, &n_sync0, 1);
 write(fd, &n_m, 1);
 write(fd, &n_s, 1);
// write(fd, &n_sync1, 1);
}
void readFiles(int* throttle, int* steering)
{
	FILE* t_f = fopen(THROTTLE_FILE, "r");
	FILE* s_f = fopen(STEERING_FILE, "r");

	fscanf(t_f, "%d", throttle);
	fscanf(s_f, "%d", steering);
	fclose(t_f);
	fclose(s_f);
}

void* swrite(void* arg)
{
 int* v = (int*)arg;
 int fd = open_port(ACM0);
 fd = configure_port(fd);
 char bytes[4] = {HEADER_BYTE, 60, -90, TRAILER_BYTE};
 //sync bytes
// write(fd, &bytes[0], 1);
 //msg bytes
 write(fd, &bytes[1], 1);
 write(fd, &bytes[2], 1);

 char last_bytes[2] = {-1, -1};
 while(*v)
 {
  int t, s;
  readFiles(&t, &s);

   bytes[1] = ((t-1000)/10);
   bytes[2] = -(char)s;

   if(bytes[1] == last_bytes[0] && bytes[2] == last_bytes[1]) continue;

   last_bytes[0] = bytes[1];
   last_bytes[1] = bytes[2];
  //sync bytes
//  printf("Writing throttle = [ %d ], steering = [ %d ]\n", (bytes[1] * 10 + 1000), bytes[2]);
  //write(fd, &bytes[0], 1);
  //msg bytes
  write(fd, &bytes[1], 1);
  write(fd, &bytes[2], 1);
  printf("Throttle = %d\nSteering = %d\n\n", (bytes[1] * 10) + 1000, s);

  //write(fd, &bytes[3], 1);
 }
 bytes[1] = 60;
 bytes[2] = -90;

 //sync bytes
// write(fd, &bytes[0], 1);
 //msg bytes
 write(fd, &bytes[1], 1);
 write(fd, &bytes[2], 1);

// write(fd, &bytes[3], 1);
 close(fd);
 return NULL;
}

void* sread(void* arg)
{
 int* v = (int*)arg;
 int fd = open_port(ACM1);
 fd = configure_port(fd);
 //char last_byte = 0;
 while(*v)
 {
  char byte;
  read(fd, &byte, 1);
  if(byte == 0) continue;
//  if(byte == last_byte) continue;
 // last_byte = byte;
  printf("Tachometer: %u\n", byte);
 }
 close(fd);
 return NULL;
}

int main(int argc, char** argv)
{
  int value = 1;
  pthread_t thread;

  int rc;
  pthread_attr_t attr;
  struct sched_param param;

  rc = pthread_attr_init (&attr);
  rc = pthread_attr_getschedparam (&attr, &param);
  (param.sched_priority)++;
  rc = pthread_attr_setschedparam (&attr, &param);


  if(argc > 1)
  {
  //create a read thread
   if(strcmp(argv[1], "read") == 0)
   {
    pthread_create(&thread, &attr, sread, &value);
   } else {
  //create a write thread
    pthread_create(&thread, &attr, swrite, &value);
   }

  //main thread
   while(value)
   {
    scanf("%d", &value);
   }
   pthread_join(thread, NULL);
  } else {
  //clear port settings
   int fd = open_port(ACM0);
   fd = configure_port(fd);
   char byte_t = 60, byte_s = -90;
   write(fd, &byte_t, 1);
   write(fd, &byte_s, 1);
   close(fd);
  }
  return 0;
}

int open_port(const char* port)
{
  int fd;
  fd = open(port, O_RDWR | O_NOCTTY | O_NDELAY);

  if(fd == -1)
  {
    printf("open_port: Unable to open %s.\n", port);
  } else {
    fcntl(fd, F_SETFL, 0);
    printf("port is open.\n");
  }
  return fd;
}

int configure_port(int fd)
{
  struct termios port_settings;
  cfsetispeed(&port_settings, B9600);
  cfsetospeed(&port_settings, B9600);

  port_settings.c_cflag &= ~PARENB;
  port_settings.c_cflag &= ~CSTOPB;
  port_settings.c_cflag &= ~CSIZE;
  port_settings.c_cflag |= CS8;

  tcsetattr(fd, TCSANOW, &port_settings);
  return fd;
}
