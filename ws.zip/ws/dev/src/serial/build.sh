g++ -pthread -o $1_serial serial.cpp
