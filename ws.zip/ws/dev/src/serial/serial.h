#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <time.h>
#include <pthread.h>

#define CURSE

#define ERROR_THRESHOLD 1000

#define FULL_REVERSE 1000
#define NEUTRAL 1600
#define FULL_THROTTLE 2000

#define FULL_LEFT 60
#define PARK_ANGLE 90
#define FULL_RIGHT 130

#define ACM0 "/dev/ttyACM0"
#define ACM1 "/dev/ttyACM1"

#ifdef CURSE
#define THROTTLE_FILE "../teleop/throttle.txt"
#define STEERING_FILE "../teleop/steering.txt"
#endif

#ifndef CURSE
#define THROTTLE_FILE "../py/teleOp/throttle.txt"
#define STEERING_FILE "../py/teleOp/steering.txt"
#endif

#define HEADER_BYTE 255
#define TRAILER_BYTE 254

int THROTTLE_ERROR = 0;
int STEERING_ERROR = 0;

bool collision_detected = false;

//get the serial device
int open_port(const char*);

//prepare serial for writing
int configure_port(int fd);

void zeroize(int fd);

void* quit(void* arg);
