echo 1600 > throttle.txt
echo "Done"
