#!/bin/bash
#
#TeleOp Program for NSL_S2AV
#Author: Christian Theriot
#Co-author: Behrad Toghi
#Version: 1.1.0

#initialize variables to park
throttle=1600
steering=90

#some function definitions
function getKey
{
 read -rsn1 key_code
}
function showDash
{
 var="$throttle"
 file="throttle.txt"
 echo $var > $file

 var="$steering"
 file="steering.txt"
 echo $var > $file

 echo "****************************************************"
 echo "*****         **Networked Systems Lab**        *****"
 echo "*****           TeleOp v.1.1.0 Running         *****"
 echo "*****                                          *****"
 echo "***** Hard Left: |Q|    |W|    Hard Right: |E| *****"
 echo "*****               |A| |S| |D|                *****"
 echo "*****                             |P|          *****"
 echo "*****                   |B|       Park         *****"
 echo "*****                  Brake                   *****"
 echo "*****                                          *****"
 echo "****************************************************"
 echo "Odometry Info:"

 echo ""
 echo "Throttle = $throttle"
 echo "Steering = $steering"
 echo ""

 echo "****************************************************"
 echo "Press \"0\" to Terminate"
 echo ""
 echo "TeleOp by: Christian Theriot and Behrad Toghi, NSL"
 echo "****************************************************"
 echo ""
}

#initialize some more variables
run=true
steer=false

while $run; do
 clear
 showDash
  if [ "$steer" = "true" ]
  then
   steering=90
   steer=false
  fi

 getKey
 if [ "$key_code" = "w" ]
 then
  if [ "$steer" = "true" ]
  then
   steering=90
   steer=false
  fi
  if [ "$throttle" -le "1950" ]
  then
   throttle=$(($throttle+2))
  fi
 fi
 if [ "$key_code" = "s" ]
 then
  if [ "$steer" = "true" ]
  then
   steering=90
   steer=false
  fi
  if [ "$throttle" -ge "1050" ]
  then
   throttle=$(($throttle-2))
  fi
 fi
 if [ "$key_code" = "d" ]
 then
  if [ "$steer" = "true" ]
  then
   steering=90
   steer=false
  fi
  if [ "$steering" -le "125" ]
  then
   steering=$(($steering+1))
  fi
 fi
 if [ "$key_code" = "a" ]
 then
  if [ "$steer" = "true" ]
  then
   steering=90
   steer=false
  fi
  if [ "$steering" -ge "65" ]
  then
   steering=$(($steering-1))
  fi
 fi
 #if [ "$steer" = "true" -a "$key_code" -ne "e" -a "$keycode" -ne "q" ]
 #then
 # steering=90
 # steer=false
 #fi
 if [ "$key_code" = "q" ]
 then
  steering=65
  steer=true
 fi
 if [ "$key_code" = "e" ]
 then
  steering=125
  steer=true
 fi
# if [ "$key_code" = "b" ]
# then

# fi
 if [ "$key_code" = "p" ]
 then
  throttle=1600
  steering=90
 fi
 if [ "$key_code" = "0" ]
 then
  echo " **Program Terminated** "
  exit 0
 fi
done

