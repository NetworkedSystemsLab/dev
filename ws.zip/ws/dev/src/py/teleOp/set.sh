echo $1 > throttle.txt
sleep $2
echo 1000 > throttle.txt
echo "Done"
sleep 3
echo 1600 > throttle.txt

