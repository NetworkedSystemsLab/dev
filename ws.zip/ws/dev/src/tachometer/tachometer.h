#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <time.h>
#include <sys/time.h>
#include <iostream>
#include <string>
#include <unistd.h>
#include <pthread.h>
#include "../lib/jetsonTX2.h"

#define TIMER struct timeval
TIMER begin, end;

void initTimer()
{
 gettimeofday(&begin, NULL);
}
double millis()
{
 gettimeofday(&end, NULL);
 double seconds = end.tv_sec - begin.tv_sec;
 double useconds = end.tv_usec - begin.tv_usec;
 double mseconds = ((seconds * 1000) + (useconds / 1000));

 return mseconds;
}

void* checkKeyboard(void* args)
{
 int* RUNNING = (int*)args;

 while(*RUNNING)
 {
  scanf("%d", RUNNING);
 }

 pthread_exit(NULL);
}

#define TACHOMETER pin13
#define SYS_FS_LOCATION "/sys/class/gpio/gpio397/value"
