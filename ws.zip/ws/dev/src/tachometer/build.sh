sudo rm -rf tach.sh
g++ -pthread -o tach.sh tachometer.cpp ../lib/jetsonTX2.c

