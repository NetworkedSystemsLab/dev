sudo ./build.sh
sudo ./tach.sh $1 $2

