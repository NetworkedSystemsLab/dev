#include "tachometer.h"

#define ROTATIONS 13

float checkRPM();
int main(int argc, char** argv)
{
 int RUNNING = 1;
 pthread_t thread;
 pthread_create(&thread, NULL, checkKeyboard, &RUNNING);

 int __COUNTS__ = 0;
 __COUNTS__ = atoi(argv[1]);
 int __SPEED__ = 0;
 __SPEED__ = atoi(argv[2]);
 printf("This iteration's\nCounts=%d\nSpeed=%d\n", __COUNTS__, __SPEED__);
 if(FILE* pin_exists = fopen(SYS_FS_LOCATION, "r"))
 {
  fclose(pin_exists);

  gpioUnexport(TACHOMETER);
 }

 gpioExport(TACHOMETER);
 gpioSetDirection(TACHOMETER, 0);
 double total_rpm = 0.0;
 double amount = 0;
 unsigned int num_zeros = 0;
 unsigned int count = 0;
 unsigned edges[2] = {0, 0};
 gpioGetValue(TACHOMETER, &edges[0]);
 initTimer();
 char buffers[3][128];
 sprintf(buffers[0], "files/tachs_counts_%d_speed_%d.txt", __COUNTS__, __SPEED__);
 sprintf(buffers[1], "files/times_counts_%d_speed_%d.txt",__COUNTS__,  __SPEED__);
 sprintf(buffers[2], "files/raw_2000.txt");

 printf("Files:\n\'%s\'\n\'%s\'\n", buffers[0], buffers[1]);
 FILE* tachs = fopen(buffers[0], "w");
 FILE* times = fopen(buffers[1], "w");
 FILE* raw = fopen(buffers[2], "w");


 double total_distance = 0;
 double last_rpm = 0;
 double last_time = 0;
 while(RUNNING)
 {
  while(RUNNING && count < __COUNTS__)
  {
   edges[1] = edges[0];
   while(RUNNING && edges[1] == edges[0])
   {

    static int last_total_distance = total_distance;
    total_distance += (last_rpm * 4.31 * 2.54 * 3.14159 / 30000) * (millis() - last_time);
    if(last_total_distance != total_distance)
     printf("Total dist: %lf\n", total_distance);

//    FILE* throt = fopen("../teleop/throttle.txt", "w");
  //  fprintf(throt, "%d", __SPEED__);
    //fclose(throt);
    if(total_distance > 100)
    {
 //    FILE* throt = fopen("../teleop/throttle.txt", "w");
   //  fprintf(throt, "1600");
     //fclose(throt);
//     RUNNING = 0;
  //   break;
    }
    gpioGetValue(TACHOMETER, &edges[0]);
    if(edges[0] != edges[1])
    {
     double time = millis();
//     printf("%d @ %lf ms\n", edges[0], time);
     count++;
    }
   }
  }

  double time = millis() - last_time;
  last_time = millis();

  double rpm = (count*30000)/time;
  last_rpm = rpm;
  fprintf(tachs, "%lf\n", rpm);
  fprintf(times, "%lf\n", time);
  count = 0;
 /* double rps = 0;
  if(last_count != count)
  {
	  rps = (double)(count/(millis()*2));
  if(num_zeros == 0)
	  printf("Rev/millis: %lf\n", rps);
  initTimer();
  if(count == 0)
  {
   num_zeros++;
  }
  if(count != 0)
  {
   fprintf(tachs, "%lf\n", rps);
   fprintf(times, "%lf\n", rps > 0 ? count/(rps*2) : 0);
   num_zeros = 0;
   total_rpm += rps;
   amount++;
   printf("New avg rps: %lf\n", (total_rpm / amount));
  }
  last_count = count;
*/
  count = 0;
 }
 fclose(tachs);
 fclose(times);
 fclose(raw);
 gpioUnexport(TACHOMETER);

 pthread_exit(NULL);
}
/*
float checkRPM()
{
 initTimer();

 unsigned risingEdge = 255;
 unsigned fallingEdge = 0;
 float count = 0;
 while(millis() < 500 && count < 20)
 {
  gpioGetValue(TACHOMETER, &risingEdge);
  while(risingEdge == fallingEdge)
  {
   gpioGetValue(TACHOMETER, &risingEdge);
//   printf("Timer: %f\n", millis());
   if(millis() >= 500) break;
  }
  if(risingEdge != fallingEdge)
  {
   if(millis() >= 500)
   {
    return ((count + 1) / millis());
   }
   count++;
   fallingEdge = risingEdge;
   initTimer();
  }
 }

 return (count/(2 * millis()));
}
*/
