git commit
git push
clear
git status

