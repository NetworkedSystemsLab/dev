Arduino code.
