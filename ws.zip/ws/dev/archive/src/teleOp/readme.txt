Includes Python2.7 teleOp dashboard 
Please first install the dependencies:
import math
import keyboard
import os
import time


----
For the c++ file, run
./cmake
./teleop

in order to run the C++ version of teleop, to be used over ssh

