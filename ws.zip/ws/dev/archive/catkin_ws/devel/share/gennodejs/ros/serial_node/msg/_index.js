
"use strict";

let Serial = require('./Serial.js');

module.exports = {
  Serial: Serial,
};
