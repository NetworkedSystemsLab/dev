**************************************************
archive is:
~/dev/archive/

nvidia@tegra-ubuntu:~/dev/archive$ ls

#runs and uses US to detect obstacles and stops until obstacle exists
basic_collision_ultrasonic.cpp  

#blinks an LED an gpio398
gpio_write.cpp           

#jetson hacks US library  
ultrasonic_library.cpp

#jetson hacks US header
ultrasonic_library.h

#serial number write on ROS
serial.cpp                 

#jetson hacks gpio access library
gpio_jetson_library.c           
gpio_jetson_library.h   

#Christian's USB write 
serial_write_one_byte.cpp  
serial_write_two_byte.cpp

#read distance 
ultrasonic_test.cpp
