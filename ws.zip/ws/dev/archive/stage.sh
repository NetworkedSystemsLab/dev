git add $1
git status

