#include "_serial.h"
#include "../tachometer/_tach.h"

int serial = 0;
pthread_mutex_t mutex;
char dist = 0, park_t = 60, park_s = -(char)90;

unsigned long milliseconds = 0;
unsigned long seconds = 0;
unsigned long minutes = 0;
unsigned long hours = 0;

void* read_arduino(void* args)
{
 while(*(int*)args)
 {
  char c;
  pthread_mutex_lock(&mutex);
  read(serial, &c, 1);
  pthread_mutex_unlock(&mutex);
  printf("%c", c);
 }
 pthread_exit(NULL);
}
void* print_arduino(void* args)
{
 while(*(int*)args)
 {
  pthread_mutex_lock(&mutex);
  write(serial, &dist, 1);
  pthread_mutex_unlock(&mutex);
  sleep(1000);
 }
 pthread_exit(NULL);
}
void* t_motor(void* args)
{
 int last_val = 0;
 while(*(int*)args)
 {
  int val = 1600;
  char byte = 60;
  FILE* fp = fopen("../py/teleOp/throttle.txt", "r");
  if(fp)
  {
   fscanf(fp, "%d", &val);
   if(last_val == val)
   {
    fclose(fp);
    continue;
   }
   printf("Motor: %d\n", val);
   last_val = val;
   byte = (char)((val - 1000)/10);
   pthread_mutex_lock(&mutex);
   tcflush(serial, TCIFLUSH);
   write(serial, &byte, 1);
   pthread_mutex_unlock(&mutex);
   fclose(fp);
  }
 }
 pthread_exit(NULL);
}
void* t_servo(void* args)
{
 int last_val = 0;
 while(*(int*)args)
 {
  int val = 90;
  char byte = -(char)90;
  FILE* fp = fopen("../py/teleOp/steering.txt", "r");
  if(fp)
  {
   fscanf(fp, "%d", &val);
   if(last_val == val)
   {
    fclose(fp);
    continue;
   }
   printf("Steering: %d\n", val);
   last_val = val;
   byte = -(char)val;
   pthread_mutex_lock(&mutex);
   tcflush(serial, TCIFLUSH);
   write(serial, &byte, 1);
   pthread_mutex_unlock(&mutex);
   fclose(fp);
  }
 }
 pthread_exit(NULL);
}

int main(int argc, char** argv)
{
 int SYNC = 1;
 serial = open_port();
 write(serial, &dist, 1);
 write(serial, &park_t, 1);
 write(serial, &park_s, 1);

 pthread_t threads[4];
 void* (*callbacks[4])(void*) = {t_motor, t_servo};
 for(int i = 0; i < 2; i++)
 {
  pthread_create(&threads[i], NULL, callbacks[i], &SYNC);
 }
 while(SYNC)
 {
  char key;
  scanf("%c", &key);
  SYNC = (key == 'q' || key == 'z' || key == '0') ? 0 : 1;
  if(key == 's')
  {
   pthread_mutex_lock(&mutex);
   write(serial, &dist, 1);
   pthread_mutex_unlock(&mutex);
 }
 }
 printf("Stopping: %d\n", SYNC);
 pthread_mutex_lock(&mutex);
 write(serial, &park_t, 1);
 pthread_mutex_unlock(&mutex);
 for(int i = 0; i < 2; i++)
 {
  pthread_cancel(threads[i]);
 }
 write(serial, &park_t, 1);
 pthread_exit(NULL);
}
