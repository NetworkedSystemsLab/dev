#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sched.h>
#include <sys/select.h>
#include <termios.h>
#include <pthread.h>

#define FULL_REVERSE 1000
#define NEUTRAL 1600

#define FULL_THROTTLE 2000

#define FULL_LEFT 60
#define PARK_ANGLE 90
#define FULL_RIGHT 130

#define ACM0 "/dev/ttyACM0"
#define ACM1 "/dev/ttyACM1"

#define THROTTLE_FILE "../py/teleOp/throttle.txt"
#define STEERING_FILE "../py/teleOp/steering.txt"

#define SIG_SYSTEM pin15
#define SIG_SYSTEM_FS "/sys/class/gpio/gpio255/value"

//get the serial device
int open_port(void);

//prepare serial for writing
int configure_port(int fd);

class SerialData
{
public:
 int throttle;
 int steering;
 int serial;
 int RUNNING;

 SerialData( int, int isRunning=1 );
 int update(void);
 void send(void);
};

class Thread
{
public:
 pthread_t thread;
 void* (*callback)(void*);
 void* args;

 Thread( void* (*cb)(void*), void* data, bool launchNow=true );
 void launch();
 static void close();
};
