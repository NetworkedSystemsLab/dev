#ifndef __MAIN_H__
#define __MAIN_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <time.h>
#include <sys/time.h>
#include <iostream>
#include <string>
#include <unistd.h>
#include <pthread.h>
#include "../lib/jetsonTX2.h"

#define EMERGENCY_SIGNAL_PIN pin15
#define ESP_SYSFS "/sys/class/gpio/gpio255/value"

void* checkKeyboard(void* args)
{
 int* RUNNING = (int*) args;
 while(*RUNNING)
 {
  char c;
  scanf("%c", &c);
  *RUNNING = (c == 'q' || c == '0') ? 0 : 1;
 }

 pthread_exit(NULL);
}

void setup()
{
 if(FILE* pin_exists = fopen(ESP_SYSFS, "r"))
 {
  fclose(pin_exists);
  gpioUnexport(EMERGENCY_SIGNAL_PIN);
 }
 gpioExport(EMERGENCY_SIGNAL_PIN);
 gpioSetDirection(EMERGENCY_SIGNAL_PIN, 1);
 gpioSetValue(EMERGENCY_SIGNAL_PIN, 1);
}

#endif
