#include "_serial.h"

static bool show_arduino = false;
void* readKeyboard( void* args )
{
 SerialData* data = (SerialData*)args;

 while( data->RUNNING )
 {
  char c;
  scanf("%c", &c);
  if(c == 'q')
  {
   data->RUNNING = 0;
  }
  if(c == 'f')
  {
   tcflush( data->serial, TCIFLUSH );
  }
  if(c == 'a')
  {
   show_arduino = !show_arduino;
  }
 }

 Thread::close();
}
void* readSerial( void* args )
{
 SerialData* data = (SerialData*)args;

 while( data->RUNNING )
 {
  char c;
//  read( data->serial, &c, 1 );
 // if(show_arduino)
//	  printf("%c", c);
 }

 Thread::close();
}

int main(int argc, char** argv)
{
 //create the sync object to link all three threads
 int serial = open_port();
/* SerialData data( open_port() );
 data.throttle = 1600;
 data.steering = 90;
 data.send();

 Thread keyThread( readKeyboard, &data );
 Thread readThread( readSerial, &data );
*/
 int t=60, s=90;
 char byte = t;
 write(serial, &byte, 1);
 while(1)
 {
  FILE* fp = fopen("../py/teleOp/steering.txt", "r");
  fscanf(fp, "%d", &s);
  fclose(fp);
  printf("S = %d\n", s);
  byte = -(char)s;
  write(serial, &byte, 1);
  sleep(0.5);
 }

// data.throttle = 1600;
// data.steering = 90;
 //data.send();
 //close( data.serial );
 Thread::close();
}
