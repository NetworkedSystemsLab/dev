echo $1 > throttle.txt
sleep 5
echo $2 > throttle.txt
sleep 3
echo $1 > throttle.txt
sleep 5
echo $2 > throttle.txt
sleep 3
echo $1 > throttle.txt
sleep 5
echo $2 > throttle.txt
sleep 3
echo "Done"
