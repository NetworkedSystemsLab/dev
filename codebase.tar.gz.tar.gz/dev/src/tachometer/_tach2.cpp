#include "_tach.h"

#define CHECK_IF_PARKED()\
  cur_speed = isMoving();\
  parked = cur_speed == 0 || (last_speed > 0 && cur_speed <= 0) || (last_speed < 0 && cur_speed >= 0);
#define CHECK_IF_PARKED_AND_CALIBRATED() (parked && calibrated)
#define CALIBRATE()\
  counts_to_ignore = 3 - edges[0];\
  initTimer(&LOCAL_TIMER);\
  calibrated = true


int isMoving(void)
{
 FILE* throt = fopen("../py/teleOp/throttle.txt", "r");
 int speed = 0;
 fscanf(throt, "%d", &speed);
 fclose(throt);
 return speed - 1600;
}

int main(int argc, char** argv)
{
 int RUNNING = 1;
 pthread_t thread;
 pthread_create(&thread, NULL, checkKeyboard, &RUNNING);

 int __COUNTS__ = 0;
 if(argc >= 1)
	 __COUNTS__ = atoi(argv[1]);
 int __SPEED__ = 0;
 if(argc >= 2)
	 __SPEED__ = atoi(argv[2]);
 int __ITERATION__ = 0;
 if(argc >= 3)
	 __ITERATION__ = atoi(argv[3]);
// printf("This iteration's\nCounts=%d\nSpeed=%d\n", __COUNTS__, __SPEED__);
 if(FILE* pin_exists = fopen(SYS_FS_LOCATION, "r"))
 {
  fclose(pin_exists);

  gpioUnexport(TACHOMETER);
 }

 gpioExport(TACHOMETER);
 gpioSetDirection(TACHOMETER, 0);
 unsigned edges[2];
 gpioGetValue(TACHOMETER, &edges[0]);
 edges[1] = edges[0];

 initTimer(&GLOBAL_TIMER);
// char buffers[3][128];
// sprintf(buffers[0], "files/tachs_iter_%d_counts_%d_speed_%d.txt", __ITERATION__, __COUNTS__, __SPEED__);
// sprintf(buffers[1], "files/times_iter_%d_counts_%d_speed_%d.txt",__ITERATION__, __COUNTS__,  __SPEED__);

// printf("Tachometer started %s\nFiles:\n\'%s\'\n\'%s\'\n", (edges[0] == 0 ? "LOW" : "HIGH"), buffers[0], buffers[1]);
// FILE* tachs = fopen(buffers[0], "w");
// FILE* times = fopen(buffers[1], "w");

 //get the first rotation
 char buffer[2][128];
 sprintf(buffer[0], "files/rpms_iteration_%d_for_speed_of_%d_with_%d_sample_size.txt", __ITERATION__, __SPEED__, __COUNTS__);
 sprintf(buffer[1], "files/raw_iteration_%d_for_speed_of_%d_with_%d_sample_size.txt", __ITERATION__, __SPEED__, __COUNTS__);
 FILE* rpm_file = fopen(buffer[0], "w");
 FILE* raw_file = fopen(buffer[1], "w");
 double rpm = 0;
 bool calibrated = false;
 bool parked = true;
 int last_speed = 1600;
 int cur_speed = 1600;
 while(RUNNING)
 {
  rpm = 0;
  calibrated = false;
  parked = true;
  last_speed = 1600;
  cur_speed = 1600;
#define GETTING_EDGES_OR_TIMING_OUT RUNNING && counts < 2 * __COUNTS__ && local_time < 1000 && !CHECK_IF_PARKED_AND_CALIBRATED()

  initTimer(&LOCAL_TIMER);
  edges[1] = edges[0];
  gpioGetValue(TACHOMETER, &edges[0]);
  unsigned counts = 0;
  unsigned counts_to_ignore = 3 * __COUNTS__;
  bool ignore_counts = false;
  int delta = isMoving(); //get the current speed value (can be 1600 or anything)
  double local_time = millis(&LOCAL_TIMER);
  while (GETTING_EDGES_OR_TIMING_OUT)
  {
     CHECK_IF_PARKED();
     while (edges[0] == edges[1] && GETTING_EDGES_OR_TIMING_OUT)
     {
        CHECK_IF_PARKED();
        if(!parked && !calibrated)
        {
         CALIBRATE();
        }

 	gpioGetValue(TACHOMETER, &edges[0]);
        local_time = millis(&LOCAL_TIMER);
     }
     fprintf(raw_file, "%u %lf %lf\n", edges[0], local_time, millis(&GLOBAL_TIMER));
     counts++;

     if(counts > counts_to_ignore)
     {
      counts -= counts_to_ignore;
      counts_to_ignore = 3 * __COUNTS__;
     }
     edges[1] = edges[0];
  }

  if(counts == 2 * __COUNTS__)
  {
   rpm = 60000.0 * __COUNTS__ / local_time;
   printf("rpm: %lf\n", rpm);
  } else {
   printf("rpm: 0\n");
  }
  fprintf(rpm_file, "%lf %lf\n", rpm, local_time);
 }
 fclose(rpm_file);
 fclose(raw_file);

// fclose(tachs);
// fclose(times);
 gpioUnexport(TACHOMETER);

 pthread_exit(NULL);
}

#undef GETTING_EDGES_OR_TIMING_OUT

