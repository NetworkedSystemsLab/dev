#include "main.h"

#define desyncro(rs)\
 rs->syncronizer = 0

bool _run_once = false;
unsigned ticks = 0;
bool calibrating = false;
bool show_debug = true;
pthread_mutex_t mutex;

//function definitions
double min(double a, double b);
double max(double a, double b);
void goNeutral();
//void brake(Tachometer* tacho);
void brake(unsigned level, double time);
void hard_brake(Tachometer* tach)
{
   TIMER brake_timer;
 //read in initial speed
   unsigned initial_speed = 0;
   FILE* fp = fopen(MAIN_THROTTLE_FILE, "r");
   fscanf(fp, "%u", &initial_speed);
   fclose(fp);

   bool moving_forward = initial_speed > 1600 ? true : false;
   bool moving_reverse = initial_speed < 1600 ? true : false;
   if(!moving_forward && !moving_reverse) return; //already parked
   fp = fopen("brake_func.txt", "a");
   initTimer(&brake_timer);
   for(unsigned speed = moving_forward ? 1200 : 1800;
      ((moving_forward && speed < 1600) || (moving_reverse && speed > 1600)) && millis(&brake_timer) < 7000;
      speed += (moving_forward ? 50 : -50))
   {
    double time_ms = millis(&brake_timer);
    if(DEBUG_FLAGS & DEBUG_BRAKE)
     printf("Brake timer: %lf milliseconds\n", time_ms);
/*
    if(1000 <= initial_speed && initial_speed < 1400)
    {
     //brake softly
     brake(1700, 75);
     fprintf(fp, "%u %lf\n", 1700, time_ms);
     brake(1650, 75);
     fprintf(fp, "%u %lf\n", 1650, millis(&brake_timer));
    }
    else if(1400 <= initial_speed && initial_speed < 1550)
    {
     //brake hard
     brake(1800, 75);
     fprintf(fp, "%u %lf\n", 1800, time_ms);
     brake(1700, 75);
     fprintf(fp, "%u %lf\n", 1700, millis(&brake_timer));
    }
    else if(1550 <= initial_speed && initial_speed < 1650)
    {
     goNeutral();
     fclose(fp);
     _run_once = false;
     return;
    }
    else if(1650 <= initial_speed && initial_speed < 1700)
    {*/
     //brake hard
     brake(moving_forward ? 1200 : 1800, 75);
     fprintf(fp, "%u %lf %lf\n", moving_forward ? 1200 : 1800, tach->rpm, time_ms);
     brake(moving_forward ? 1500 : 1700, 75);
     fprintf(fp, "%u %lf %lf\n", moving_forward ? 1500 : 1700, tach->rpm, millis(&brake_timer));
/*    }
    else if(1700 <= initial_speed && initial_speed <= 2000)
    {
     //brake softly
     brake(1350, 75);
     fprintf(fp, "%u %lf\n", 1500, time_ms);
     brake(1550, 75);
     fprintf(fp, "%u %lf\n", 1550, millis(&brake_timer));
    }
    else
    {
     //idk, just go to neutral
     goNeutral();
     fclose(fp);
     _run_once = false;
     return;
    }
*/
   }
   goNeutral();
   tach->revolutions = 0;
   fprintf(fp, "1600 0 %lf\n", millis(&brake_timer));
   fclose(fp);
   _run_once = false;
}

int main(int argc, char** argv)
{
 initPin(SIG_SYSTEM, SIG_SYSTEM_SYSFS, 1);
 writePin(SIG_SYSTEM, 1);
 Serial port;
 Tachometer tacho;
 port.begin(B9600);
 Keyboard* kb = new Keyboard;
#ifdef SONARS_ARE_IMPLEMENTED
 Sonar sonar[NUM_SONARS] = {
  Sonar(SONAR_ECHO_0, SONAR_ECHO_0_SYSFS, SONAR_TRIG_0, SONAR_TRIG_0_SYSFS),
  Sonar(SONAR_ECHO_1, SONAR_ECHO_1_SYSFS, SONAR_TRIG_1, SONAR_TRIG_1_SYSFS),
  Sonar(SONAR_ECHO_2, SONAR_ECHO_2_SYSFS, SONAR_TRIG_2, SONAR_TRIG_2_SYSFS),
  Sonar(SONAR_ECHO_3, SONAR_ECHO_3_SYSFS, SONAR_TRIG_3, SONAR_TRIG_3_SYSFS)
 };
#endif

 Thread* accelerometer = new Thread(Tachometer::read_tach, &tacho);
 accelerometer->launch();

 Thread* writer = new Thread(Serial::write_serial, &port);
 writer->launch();

 Thread* reader = new Thread(Serial::read_serial, &port);
 reader->launch();

 Thread* kbr = new Thread(Keyboard::read_keyboard, kb);
 kbr->launch();

#ifdef SONARS_ARE_IMPLEMENTED
 Thread* th_sonar[NUM_SONARS];
 for(unsigned iterator = 0; iterator < NUM_SONARS; iterator++)
 {
  th_sonar[iterator] = new Thread(Sonar::read_dist, &sonar[iterator]);
  th_sonar[iterator]->launch();
 }
#endif

 TIMER brake_timer;
 char c = kb->getKey();
 FILE* fp = NULL;
 TIMER print_sonar_timer;
 initTimer(&print_sonar_timer);
 while(kb && c != 'q')
 {
  unsigned cur_speed;
  unsigned interval = 0;
  fp = fopen(MAIN_THROTTLE_FILE, "r");
  fscanf(fp, "%u", &cur_speed);
  fclose(fp);

#ifdef SONARS_ARE_IMPLEMENTED
  bool reset_timer = false;
  if(millis(&print_sonar_timer) > 500 && (DEBUG_FLAGS & DEBUG_SONAR))
   printf("\n");
  for(int i = 0; i < 4; i++)
  {
   if(millis(&print_sonar_timer) > 500 && (DEBUG_FLAGS & DEBUG_SONAR))
   {
    printf("SENSOR %d: %lf\n", i, sonar[i].distance);
    reset_timer = true;
   }
  }
  if(reset_timer && (DEBUG_FLAGS & DEBUG_SONAR))
  {
   printf("\n");
   initTimer(&print_sonar_timer);
   reset_timer = false;
  }

  static bool sonars_demand_park = false;
  if(cur_speed > 1600)
  {
   if(sonar[1].distance < SONAR_STOP_DISTANCE || 
      sonar[0].distance < SONAR_STOP_DISTANCE)
   {
    hard_brake(&tacho);
    sonars_demand_park = true;
   } else {
    sonars_demand_park = false;
   }
  }
  else if(cur_speed < 1600)
  {
   if(sonar[2].distance < SONAR_STOP_DISTANCE ||
      sonar[3].distance < SONAR_STOP_DISTANCE)
   {
    hard_brake(&tacho);
    sonars_demand_park = true;
   } else {
    sonars_demand_park = false;
   }
  }
  else
  {
   if(sonars_demand_park)
   {
    sonars_demand_park = false;
    fp = fopen(MAIN_THROTTLE_FILE, "w");
    fprintf(fp, "1600");
    fclose(fp);
    writePin(SIG_SYSTEM, 0);
   }
   //stay neutral
  }
#endif

/*  if(cur_speed < 1600 || cur_speed > 2000)
   interval = -1;

  if(1600 < cur_speed && cur_speed < 1700)
   interval = 1;

  if(1700 <= cur_speed && cur_speed < 1850)
   interval = 2;

  if(1850 <= cur_speed && cur_speed <= 2000)
   interval = 3;
*/
  char next_char = kb->getKey();
  switch(c)
  {
  case 'l':
   fp = fopen(MAIN_STEERING_FILE, "w");
   fprintf(fp, "60");
   fclose(fp);
   break;
  case 'r':
   fp = fopen(MAIN_STEERING_FILE, "w");
   fprintf(fp, "120");
   fclose(fp);
   break;
  case 'd':
   show_debug = !show_debug;
   printf("Debug info %s\n", show_debug ? "ON" : "OFF");
   break;
  case 't':
   if(show_debug)
    printf("Odom: %lf inches\n", tacho.odometer);
   break;
  case 'f':
   if(show_debug)
    printf("\nFlushing...\n");
   while(!port.received.empty())
   {
    std::string next = port.Next();
    if(next.find("idle") == std::string::npos && show_debug)
    {
     printf("%s\t[%4d arduino msgs left]\n", next.c_str(), port.received.size());
    }
   }
   if(show_debug)
    printf("Finished flushing.\n\n");
   break;
  case 'b':
/* unsigned step = 400;
 unsigned delta_step = 50;
 double pwm = 100;
 TIMER break_timer;*
   initTimer(&break_timer);
   last_time = 0;

   printf("cftgkm: %lf\n", millis(&break_timer));*/
//   hard_break(interval, 0);

  //brake();
  /* fp = fopen(MAIN_THROTTLE_FILE, "w");
   fprintf(fp, "1600");
   fclose(fp);

  *
   brake(1200, 75, true);
   initTimer(&brake_timer);
   for(unsigned speed = 1200; speed < 1600 && millis(&brake_timer) < 2000; speed += 50)
   {
    brake(speed, 75);
   }
   goNeutral();
   */
   hard_brake(&tacho);
   fp = fopen(MAIN_STEERING_FILE, "w");
   fprintf(fp, "90");
   fclose(fp);

   break;
  case 'h':
   calibrating = true; //calibrate the tachometer to 0 revolutions
   tacho.odometer = 0; //calibrate the odometer to 0 cm/inches
   _run_once = true;
   if(show_debug)
    printf("Calibrating tachometer\n");
   ticks = 0;
   fp = fopen(MAIN_THROTTLE_FILE, "w");
   fprintf(fp, "%d", TERM_SPEED);
   fclose(fp);
   if(show_debug)
    printf("Hard braking\n");
   hard_brake(&tacho);
   break;
  case 'e':
   fp = fopen(MAIN_THROTTLE_FILE, "w");
   fprintf(fp, "1600");
   fclose(fp);
   writePin(SIG_SYSTEM, 1 - readPin(SIG_SYSTEM));
   break;
  case '1':
   fp = fopen(MAIN_THROTTLE_FILE, "w");
   fprintf(fp ,"1000");
   fclose(fp);
   break;
  case '2':
   fp = fopen(MAIN_THROTTLE_FILE, "w");
   fprintf(fp, "2000");
   fclose(fp);
   break;
  case 'n':
   fp = fopen(MAIN_THROTTLE_FILE, "w");
   fprintf(fp, "1600");
   fclose(fp);
   break;
  case 'c':
   calibrating = true; //calibrate the tachometer to 0 revolutions
   tacho.odometer = 0; //calibrate the odometer to 0 cm/inches
   _run_once = true;
   if(show_debug)
    printf("Calibrating tachometer\n");
  case 's':
   ticks = 0;
   fp = fopen(MAIN_THROTTLE_FILE, "w");
   fprintf(fp, "%d", TERM_SPEED);
   fclose(fp);
   break;
/*  case 'h':
   fp = fopen(MAIN_THROTTLE_FILE, "w");
   fprintf(fp, "1200");
   fclose(fp);
   usleep(7000000);
   fp = fopen(MAIN_THROTTLE_FILE, "w");
   fprintf(fp, "1600");
   fclose(fp);
   break;
/* //causes the tachometer thread to 'freeze', I guess it's going into
   //an infinite loop but I'm not sure how to fix this.
   //Removing from functionality for now
   case 'c':
   fp = fopen(MAIN_THROTTLE_FILE, "w");
   fprintf(fp, "%d", TERM_SPEED);
   fclose(fp);
   calibrating = true;
   break;
 */ case 0:
  case '\n':
  case '\r':
   break;
  case 'q':
  case '0':
   next_char = 'q';
   break;
  default:
   std::string next = port.Next();
   while(next.find("idle") != std::string::npos && !port.received.empty())
   {
    next = port.Next();
   }
   if(next.find("idle") == std::string::npos && show_debug)
    printf("%s\n", next.c_str());
   break;
  }

  c = next_char;
 }
#ifdef SONARS_ARE_IMPLEMENTED
 for(unsigned iterator = 0; iterator < NUM_SONARS; iterator++)
 {
  sonar[iterator].syncronizer = 0;
  th_sonar[iterator]->await();
 }
#endif
 port.syncronizer = 0;
 tacho.syncronizer = 0;
 kb->syncronizer = 0;
 writer->await();
 reader->await();
 accelerometer->await();
 printf("Enter any key to quit...\n");
 kbr->await();

 delete kb;
/* system("clear");
 Keyboard* kb = new Keyboard;
 Serial* port = new Serial;
 port->begin(B9600);

 Thread* writer = new Thread(Serial::write_serial, port);
 Thread* reader = new Thread(Serial::read_serial, port);
 Thread* kbReader = new Thread(Keyboard::read_keyboard, kb);

 kbReader->launch();
 writer->launch();
 reader->launch();

 usleep(1000000);
 printf("\nPress \'d\' to toggle debug info");
 printf("\nPress \'f\' to flush the input message queue");
 /*while(1)
 {
  char c = kb->getKey();
  bool _quit = false;
/*  std::string string = kb->getStr();
   
   
  if(!c) continue;
   

  if(string.find("debug") == 0)
  {
   c = 'd';
  } else if(string.find("flush") == 0) {
   c = 'f';
  } else if(string.find("quit") == 0) {
   c = 'q';
  }*
  switch(c)
  {
  case 'd':
   show_debug = !show_debug;
   printf("\nDebug mode: %s\n\n", show_debug ? "Yes" : "No");
   break;
  case '\n':
  case '\r':
   continue;
  case 'f':
  case ' ':
   break;
  case 'q':
  case '0':
   _quit = true;
   break;
  default:
   break;
  }
  if(_quit) break;
 }*

 system("clear");
 printf("Waiting for Arduino's port to close...\n");
 desyncro(port);
 desyncro(kb);
// ((Thread*)port)->await();
 writer->await();
 reader->await();

 printf("Enter any key to quit...\n");

 usleep(10000);

 kbReader->await();
*/
 printf("Exiting main\n");
 pthread_exit(NULL);
} //main

double min(double a, double b)
{
 return a < b ? a : b;
}
double max(double a, double b)
{
 return a > b ? a : b;
}
void goNeutral()
{
  FILE* fp = fopen(MAIN_THROTTLE_FILE, "w");
  fprintf(fp, "1600");
  fclose(fp);
}
void brake(unsigned level, double ms)
{
 FILE* fp = NULL;

 //signal stop pwm
 fp = fopen(MAIN_THROTTLE_FILE, "w");
 fprintf(fp, "%u", level);
 fclose(fp);
 usleep(ms * 1000);

 //signal idle-break pwm
/* fp = fopen(MAIN_THROTTLE_FILE, "w");
 fprintf(fp, "%d", initial_speed > 1600 ? 1500 : (initial_speed < 1600 ? 1700 : 1600));
 fclose(fp);
 usleep(ms * 500);



/* unsigned initial_speed = 1600;
 FILE* fp = fopen(MAIN_THROTTLE_FILE, "r");
 fscanf(fp, "%u", &initial_speed);
 fclose(fp);

 unsigned speed = initial_speed;
 if(initial_speed > 1650)
 {
  switch(method)
  {
  case 0:
   //go full reverse and slow down
   speed = 1000;
   while(speed < 1600 && *rpm > 0)
   {
    FILE* fp = fopen(MAIN_THROTTLE_FILE, "w");
    fprintf(fp, "%u", speed);
    fclose(fp);
    usleep(HARD_BRAKE_MILLIS * 1000.0 / (1600 - speed));
    speed -= 20;
   }
   break;
  case 1:
   //go some amount of reverse based on initial speed
   speed = 1000
   break;
  default:
   goNeutral();
   return;
  }
 } else if(initial_speed < 1550) {
  switch(method)
  {
  case 0:
   //go full reverse and slow down
   break;
  case 1:
   //go some amount of reverse based on initial speed
   break;
  default:
   goNeutral();
   return;
  }
 } else {
  goNeutral();
 }
 goNeutral();*/
}






/***********************************************/
/***********************************************/
//	System library impl'n
/***********************************************/
/***********************************************/

void nano(const char* file)
{
 char buffer[512];
 sprintf( buffer, "nano %s", file );
 system( buffer );
}
void exec(const char* exe)
{
 char buffer[512];
 sprintf( buffer, "./%s", exe );
 system( buffer );
}

/***********************************************/
/***********************************************/
//	GPIO library impl'n
/***********************************************/
/***********************************************/

void initPin(jetsonGPIO pin, const char* sysfs, int direction)
{
 if(FILE* fp = fopen(sysfs, "r"))
 {
  fclose(fp);
  closePin(pin);
 }
 printf("Initializing pin %d\n", pin);
 gpioExport(pin);
 gpioSetDirection(pin, direction);
}
unsigned readPin(jetsonGPIO pin)
{
 unsigned value;
 gpioGetValue(pin, &value);
 return value;
}
void writePin(jetsonGPIO pin, unsigned value)
{
 gpioSetValue(pin, value);
}
void closePin(jetsonGPIO pin)
{
 gpioUnexport(pin);
}

/***********************************************/
/***********************************************/
//	Timer library impl'n
/***********************************************/
/***********************************************/

//(re)start a timer
void initTimer(TIMER* timer)
{
 gettimeofday(timer, NULL);
}
//get the elapsed milliseconds since the timer was (re)started
double millis(TIMER* timer)
{
 //get the timer for duration
 TIMER* end = newTimer();

 //calculate elapsed seconds
 double s = end->tv_sec - timer->tv_sec;
 //calculate elapsed microseconds
 double us = end->tv_usec - timer->tv_usec;
 //convert to milliseconds
 double ms = ((s * 1000) + (us / 1000));

 //free the resources tied to the duration timer
 delete end;
 return ms;
}
//get a new timer pointer
TIMER* newTimer()
{
 //create a new timer
 TIMER* output = new TIMER;
 //initialize it
 initTimer(output);
 //return it
 return output;
}

/***********************************************/
/***********************************************/
//	Thread library impl'n
/***********************************************/
/***********************************************/

Thread::Thread():
 thread(NULL),
 callback(Thread::delay),
 args(NULL) {}

Thread::Thread(void* (*cb)(void*), void* data):
 thread(new pthread_t),
 callback(cb),
 args(data) {}

Thread::~Thread()
{
 if(thread)
  delete thread;
}

Thread& Thread::assign(void* (*cb)(void*), void* data)
{
 if(launched) return *this;

 callback = cb;
 args = data;
 return *this;
}
void Thread::cancel()
{
 if(thread)
  pthread_cancel(*thread);
}
void Thread::launch()
{
 if(launched || !thread) return;

 pthread_create(thread, NULL, callback, args);
 launched = true;
}
void Thread::await()
{
 launch();
 if(thread)
  pthread_join(*thread, NULL);
}
void* Thread::delay(void* args)
{
 if(args)
 {
  //sleep for x usecs
  usleep(*(double*)args);
 } else {
  //sleep for 1 sec
  sleep(1);
 }
 pthread_exit(NULL);
}

/***********************************************/
/***********************************************/
//	Serial library impl'n
/***********************************************/
/***********************************************/

Serial::Serial():
 syncronizer(1) {}
Serial::~Serial()
{
 syncronizer = 0;
 //clear and close the port
 tcsetattr(fd, TCSANOW, &port_settings);
 close(fd);
}
void Serial::begin(speed_t baud)
{
  port = ACM0;
  baudrate = baud;

  //read and write mode, no blocking
  fd = open(port.c_str(), O_RDWR|O_NOCTTY|O_NDELAY);

  //error occurred
  int next_acm = 1;
  char buffer[256];
  while(fd == -1)
  {
   sprintf(buffer, "/dev/ttyACM%d", next_acm);
   printf("Unable to open port %s, trying port %s\n", port.c_str(), buffer);
   fd = open(buffer, O_RDWR|O_NOCTTY|O_NDELAY);
   next_acm++;
   if(next_acm == 0)
   {
    printf("Unable to open any port\n");
    pthread_exit(NULL);
   }
   port = buffer;
  }

  //prepare the port to change its settings
  fcntl(fd, F_SETFL, 0);
  printf("Port is open on %s\n", port.c_str());


  //set baud rates
  cfsetispeed(&port_settings, baudrate);
  cfsetospeed(&port_settings, baudrate);
  //set UART settings 8N1
  port_settings.c_cflag &= ~PARENB;
  port_settings.c_cflag &= ~CSTOPB;
  port_settings.c_cflag &= ~CSIZE;
  port_settings.c_cflag |= CS8;

  //disable Canonical mode
  port_settings.c_cflag &= ~CRTSCTS;
  port_settings.c_cflag |= CREAD|CLOCAL;
  port_settings.c_iflag &= ~(IXON|IXOFF|IXANY);
  port_settings.c_lflag &= ~(ICANON|ECHO|ECHOE|ISIG);
  port_settings.c_oflag &= ~OPOST;

  //blocking mode
  port_settings.c_cc[VMIN] = 0;
  port_settings.c_cc[VTIME] = 0;

  //set the settings and flush the port
  tcsetattr(fd, TCSANOW, &port_settings);
  tcsetattr(fd, TCSAFLUSH, &port_settings);

   
}
void Serial::Write(char c)
{
 write(fd, &c, 1);
}
std::string Serial::Read()
{
  std::string current = "";
  while(1)
  {
   char c = 0;
   int bytes = read(fd, &c, 1);

   //it's possible for read not to actually read a byte
   if(bytes > 0)
   {
    if(c == '\n' || c == '\r')
    {
     //add the current string to the queue of strings
     if(!current.empty())
      received.push_back(current);
     break;
    }
    current += c;
   }
  }

  //return the current string and leave the queue untouched
  return current;
}
std::string Serial::Next()
{
 std::string output = "";
 while(!received.empty() && output == "")
 {
  output = received.front();
  received.pop_front();

  if((int)output[0] == 13 || (int)output[1] == 10)
  {
   output = "";
  }
 }
 return output;
}
void* Serial::read_serial(void* args)
{
 printf("Launching arduino read thread\n");
 Serial* This = (Serial*)args;

 bool idle = false;
 bool last_char_whitespace = false;
 TIMER read_serial_timer;
 initTimer(&read_serial_timer);
 while(This && This->syncronizer)
 {
  std::string str = This->Read();
  if(str.size() < 1 || str[0] == '\r' || str[0] == '\n' || str.find("idle") != std::string::npos) continue;
  if(show_debug && (DEBUG_FLAGS & DEBUG_ARDUINO))
   printf("\'%s\' read from arduino\n", str.c_str());
  if(isdigit(str.c_str()[0]))
  {
   FILE* fp = fopen("arduino_log.txt", "a");
   fprintf(fp, "%s %lf\n", str.c_str(), millis(&read_serial_timer));
   fclose(fp);
   initTimer(&read_serial_timer);
  }
 }

 printf("Exiting arduino read thread\n");
 pthread_exit(NULL);
}
void Serial::clear()
{
 this->Serial::~Serial();
}
void* Serial::write_serial(void* args)
{
 printf("Launching arduino write thread\n");
 Serial* port = (Serial*)args;

 static int last_throttle = 0, last_steering = 0;
 while(port && port->syncronizer)
 {
  int a;
  char b;
  FILE* fp = fopen(MAIN_THROTTLE_FILE, "r");
  fscanf(fp, "%d", &a);
  fclose(fp);
  if(last_throttle != a)
  {
   b = (char)((a - 1000)/10);
   port->Write(b);
   last_throttle = a;
  }

  fp = fopen(MAIN_STEERING_FILE, "r");
  fscanf(fp, "%d", &a);
  fclose(fp);
  if(last_steering != a)
  {
   b = -(char)a;
   port->Write(b);
   last_steering = a;
  }
  usleep(100000);
 }

 char exit_t = 60;
 port->Write(exit_t);
 printf("Exiting arduino write thread\n");
 pthread_exit(NULL);
}

/***********************************************/
/***********************************************/
//	Keyboard input library
/***********************************************/
/***********************************************/

Keyboard::Keyboard(): syncronizer(1) {}
bool Keyboard::empty()
{
 return keys.empty();
}
char Keyboard::getKey()
{
 if(empty()) return 0;
 char top = keys.front();
 keys.pop_front();
 return top;
}
/*std::string Keyboard::getStr()
{
 static TIMER keyTimer;
 static bool calibrate_timer = true;
 if(calibrate_timer)
 {
  calibrate_timer = false;
  initTimer(&keyTimer);
 }

 std::string output = "";
 if(keys.empty())
 {
 } else {
  printf("%d\n", keys.size());
 }
 for(char c : keys)
 {
  output += c;
 }
 return output;
}*/
void* Keyboard::read_keyboard(void* args)
{
 printf("Launching keyboard thread\n");
 Keyboard* kb = (Keyboard*)args;

 while(kb && kb->syncronizer)
 {
  char c;
  scanf("%c", &c);
  kb->keys.push_back(c);
 }

 printf("Exiting keyboard thread\n");
 pthread_exit(NULL);
}

/***********************************************/
/***********************************************/
//	Tachometer library impl'n
/***********************************************/
/***********************************************/
Tachometer::Tachometer()
{
 static bool initialized = false;
 if(!initialized)
 {
  initPin(TACHOMETER, TACHOMETER_SYSFS);
  initialized = true;
 }
 syncronizer = 1;
}
Tachometer::~Tachometer()
{
 closePin(TACHOMETER);
 syncronizer = 0;
}
void* Tachometer::read_tach(void* args)
{
 Tachometer* tach = (Tachometer*)args;

 FILE* raw_f = fopen("./files/raw_tach.txt", "w");
 FILE* rpm_f = fopen("./files/tach_rpm.txt", "w");
 FILE* dist_f = fopen("./files/dist_tach.txt", "w");
 TIMER odom_timer, edge_timer, timeout, global;
 FILE *fp = NULL;

 initTimer(&odom_timer);
 initTimer(&edge_timer);
 initTimer(&timeout);
 initTimer(&global);

 bool isCalibrated = false;
 double counts = 0.0;
 unsigned values[2] = {0, 0};
 while(tach->syncronizer)
 {
  if(calibrating && counts > 1)
  {
   isCalibrated = true;
   calibrating = false;
   counts = 0;
  }
  values[1] = values[0];

  values[0] = readPin(TACHOMETER);

  //edge occurred
  if(values[0] != values[1])
  {
   fprintf(raw_f, "%u %lf\n", values[1], millis(&edge_timer));
   //full revolution occurred
   if(values[1] == 0)
   {
    tach->revolutions++;
  //  static bool _run_once = true;
    counts++;
    ticks++;
    if(DEBUG_FLAGS & DEBUG_TACH)
     printf("\nRevolutions: %u\n\n", ticks);
    if(isCalibrated)
    {
/*     static int times = 0;
     times++;
*/   if(tach->odometer >= 5 && _run_once)
     {
      if(DEBUG_FLAGS & DEBUG_TACH)
       printf("[findme: car thinks it went %lf]\n", tach->odometer);
      hard_brake(tach);
//      _run_once = false;
/*      fp = fopen(MAIN_THROTTLE_FILE, "w");
      fprintf(fp, "1600");
      fclose(fp);
 */  }
     if(tach->odometer > 5 && tach->rpm > 0 && (DEBUG_FLAGS & DEBUG_TACH))
     {
      printf("[findme: car overshot brake by %lf]\n", tach->odometer - 50);
     }
    }
    tach->odometer += DISTANCE_WHEEL_REVOLUTION / 3.0;
    if(DEBUG_FLAGS & DEBUG_TACH)
     printf("Dist: %lf inches\n", tach->odometer);
    fprintf(dist_f, "%lf %lf\n", tach->odometer, millis(&edge_timer));
   }
   initTimer(&edge_timer);
  }

  double ms = millis(&timeout);
  if(!calibrating && counts > 0)
  {
   tach->rpm = (((double)counts)/ms)*60000;
   fprintf(rpm_f, "%lf %lf\n", tach->rpm, ms);
   if(show_debug && (DEBUG_FLAGS & DEBUG_TACH))
    printf("RPM: %lf\n", tach->rpm);
   initTimer(&timeout);
   counts = 0;
  }
  if(ms > 2000)
  {
   tach->rpm = 0;
   if(show_debug && (DEBUG_FLAGS & DEBUG_TACH))
    printf("RPM: 0\n");
   initTimer(&timeout);
   counts = 0;
  }
 }
 fclose(raw_f);
 fclose(rpm_f);
 fclose(dist_f);

 pthread_exit(NULL);
}

/***********************************************/
/***********************************************/
//	Sonar library impl'n
/***********************************************/
/***********************************************/
Sonar::Sonar(jetsonGPIO ec, const char* ec_sysfs, jetsonGPIO tr, const char* tr_sysfs):
 echo(ec),
 echo_sysfs(ec_sysfs),
 trigger(tr),
 trigger_sysfs(tr_sysfs)
{
 //set echo for input
 initPin(ec, ec_sysfs, 0);
 //set trigger for output
 initPin(tr, tr_sysfs, 1);
}
Sonar::~Sonar()
{
 closePin(echo);
 closePin(trigger);
}
bool Sonar::triggerPing()
{
 double maxEcho = (MAX_SENSOR_DISTANCE * ROUNDTRIP_CM + MAX_SENSOR_DELAY)/1000;
 double echoValue = 0;
 TIMER pingTimer;

 writePin(trigger, 0);
 usleep(4); //4 microseconds LOW

 writePin(trigger, 1);
 usleep(10); //10 microseconds HIGH

 writePin(trigger, 0);
 initTimer(&pingTimer);

 echoValue = readPin(echo);
 if(echoValue) return false; //previous echo not finished

 while(echoValue != 1)
 {
  echoValue = readPin(echo);
  if(millis(&pingTimer) > maxEcho) return false;
 }
 return true;
}
double Sonar::ping()
{
 if(!triggerPing())
 {
  return NO_ECHO;
 } else {
  double maxEcho = (MAX_SENSOR_DISTANCE*ROUNDTRIP_CM + MAX_SENSOR_DELAY)/1000;
  unsigned echoValue = 1;
  TIMER pingTimer;
  initTimer(&pingTimer);
  while(echoValue != 0)
  {
   echoValue = readPin(echo);
   if(echoValue == 0) break;
   if(millis(&pingTimer) > maxEcho) return NO_ECHO;
  }
  return millis(&pingTimer);
 }
}
void* Sonar::read_dist(void* args)
{
 Sonar* sonar = (Sonar*)args;
 while(sonar && sonar->syncronizer)
 {
  sonar -> distance = sonar -> ping();
 }
 pthread_exit(NULL);
}




