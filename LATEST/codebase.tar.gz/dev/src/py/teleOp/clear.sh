echo 1600 > throttle.txt
echo 90 > steering.txt
echo "Done"
