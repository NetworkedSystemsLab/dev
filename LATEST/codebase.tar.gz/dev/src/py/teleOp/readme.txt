Includes Python2.7 teleOp dashboard 
Please first install the dependencies:
import math
import keyboard
import os
import time
