#include "../lib/main.h"

int main()
{
// nano("../py/teleOp/throttle.txt");
 exec("edit_arduino");
 return 0;
}
