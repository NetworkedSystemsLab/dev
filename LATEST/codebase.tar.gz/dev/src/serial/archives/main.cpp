#include "main.h"

int main(int argc, char** argv)
{
 int RUNNING = 1;

 pthread_t thread;
 pthread_create(&thread, NULL, checkKeyboard, &RUNNING);
 setup();

 while(RUNNING)
 {
 }

 gpioSetValue(EMERGENCY_SIGNAL_PIN, 0);
 gpioUnexport(EMERGENCY_SIGNAL_PIN);
 pthread_exit(NULL);
}
