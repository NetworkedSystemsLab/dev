#include "../include/threads.h"

thread::thread():
 _thread(NULL),
 _callback(thread::null),
 _args(NULL),
 _launched(false)
{

}
thread::thread(void*(*cb)(void*), void* data):
 _thread(new pthread_t),
 _callback(cb),
 _args(data),
 _launched(false)
{

}
thread::~thread()
{
 if(_thread)
  delete _thread;
}
thread& thread::assign(void*(*cb)(void*), void* data)
{
 if(_launched) return *this;
 _callback = cb;
 _args = data;
 return *this;
}
void thread::cancel()
{
 if(_thread)
  pthread_cancel(*_thread);
}
void thread::launch()
{
 if(_launched || !_thread) return;

 pthread_create(_thread, NULL, _callback, _args);
 _launched = true;
}
void thread::await()
{
 launch();
 if(_thread)
  pthread_join(*_thread, NULL);
}
void* thread::null(void* args)
{
 pthread_exit(NULL);
}

