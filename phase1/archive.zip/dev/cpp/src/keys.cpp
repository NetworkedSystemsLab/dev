#include "../include/keys.h"
#include "../include/threads.h"

input::input()
{
 _thread = new thread(input::poll, this);
 _thread->launch();
}

input::~input()
{
 if(_thread)
 {
  _thread->cancel();
  printf("Terminating keyboard thread by force...\n");
  //debugln("Terminating keyboard thread by force...");
  delete _thread;
 }
}

char input::getKey()
{
 char output = 0;
 if(keys.size() > 0)
 {
  output = keys[0];
  keys.erase(keys.begin());
 }
 return output;
}
void input::flush()
{
 keys.clear();
}
void* input::poll(void* args)
{
 printf("Launching keyboard thread...\n");
 //debugln("Launching keyboard thread...");
 input* source = (input*)args;

 while(source)
 {
  char c;
  scanf("%c", &c);
  source->keys.push_back(c);
 }
 pthread_exit(NULL);
}
