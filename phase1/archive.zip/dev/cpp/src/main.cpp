#include "../include/main.h"
#include "../include/serial.h"
#include "../include/tach.h"
#include "../include/keys.h"

pthread_mutex_t CAMERA_MUTEX;
pthread_mutex_t MAIN_THROTTLE_MUTEX;
pthread_mutex_t MAIN_STEERING_MUTEX;
pthread_mutex_t brake_mutex;
input* keyboard;
bool brake_commanded = false;
bool brake_disengaged = true;
TIMER global_timer;
pthread_mutex_t DEBUG_MUTEX;

tachometer* tach;
int main(int argc, char** argv)
{
 initFile(DEBUG_FILE, "", &DEBUG_MUTEX);
 //debugln("Initializing debug file");
 initTimer(&global_timer);
 #ifdef JETSON
 printf("Running main on Jetson\n");
 //debugln("Running main on Jetson");
 #else
 printf("Running main on Lubuntu\n");
 //debugln("Running main on Lubuntu");
 #endif
 printf("Launching main...\n");
 //debugln("Launching main...");

 initPin(EMERGENCY_GPIO, EMERGENCY_GPIO_SYSFS, 1);
 initPin(BRAKING_PIN, BRAKING_PIN_SYSFS, 1);

 writePin(EMERGENCY_GPIO, 1);
 usleep(100000);
 writePin(EMERGENCY_GPIO, 0);
 usleep(100000);
 writePin(EMERGENCY_GPIO, 1);
 usleep(100000);
 writePin(BRAKING_PIN, 1);

 serial arduino;

 printf("Starting arduino threads\n");
 //debugln("Starting arduino threads");
 thread serial_read(serial::_read_serial, &arduino);
 thread serial_write(serial::_write_serial, &arduino);

 serial_read.launch();
 serial_write.launch();
// arduino.threads[0] = new thread(serial::_read_serial, &arduino);
// arduino.threads[1] = new thread(serial::_write_serial, &arduino);
// arduino.threads[0]->launch();
// arduino.threads[1]->launch();

 keyboard = new input();
 tach = new tachometer(keyboard);

 printf("Begin main loop\n");
 //debugln("Begin main loop");
 int run_main = 1;
 unsigned term_speed = 1650;
 char buffer[256];
 thread* helper = NULL;

 goNeutral();

 while(run_main)
 {
  if(checkBrake())
  {
   usleep(100000);
//   continue;
  }
  char key = keyboard->getKey();
  sprintf(buffer, "%c pressed", key);
  //debugln(buffer);
  switch(key)
  {
   case 'f':
    //forward
    pthread_mutex_lock(&brake_mutex);

    brake_disengaged = true;
    brake_commanded = false;

    pthread_mutex_unlock(&brake_mutex);
    if(term_speed < 1600)
    {
     term_speed = 1600;
     printf("Forcing term_speed to 1600!\n");
     //debugln("Forcing term_speed to 1600!");
    }
    if(term_speed >= 1650)
    {
     writePin(BRAKING_PIN, 0);
    }
    sprintf(buffer, "%u", term_speed);
    //if(!checkBrake())
     initFile(MAIN_THROTTLE_FILE, buffer, &MAIN_THROTTLE_MUTEX);
    break;
   case 'b':
    //brake
    //if(!checkBrake())
    //{
     hardBrake();

//     goNeutral();
    //}
    break;
   case 'n':
    pthread_mutex_lock(&brake_mutex);
    brake_commanded = false;
    brake_disengaged = true;
    pthread_mutex_unlock(&brake_mutex);
    writePin(BRAKING_PIN, 0);
    //neutral
//    if(!checkBrake())
  //  {
     goNeutral();
   // }
    break;
   case 'c':
    //calib brake
    pthread_mutex_lock(&brake_mutex);

    brake_disengaged = true;
    brake_commanded = false;

    pthread_mutex_unlock(&brake_mutex);
    if(term_speed < 1600)
    {
     term_speed = 1600;
     printf("Forcing term_speed to 1600!\n");
     //debugln("Forcing term_speed to 1600!");
    }
    if(term_speed < 1600)
    {
     term_speed = 1600;
     printf("Forcing term_speed to 1600!\n");
     //debugln("Forcing term_speed to 1600!");
    }
    if(term_speed >= 1650)
    {
     writePin(BRAKING_PIN, 0);
    }
    sprintf(buffer, "%u", term_speed);
    initFile(MAIN_THROTTLE_FILE, buffer, &MAIN_THROTTLE_MUTEX);
    tach->calibrate();
    break;
   case 'x':
    //calib neutral
    pthread_mutex_lock(&brake_mutex);

    brake_disengaged = true;
    brake_commanded = false;

    pthread_mutex_unlock(&brake_mutex);
    if(term_speed < 1600)
    {
     term_speed = 1600;
     printf("Forcing term_speed to 1600!\n");
     //debugln("Forcing term_speed to 1600!");
    }
    if(term_speed >= 1650)
    {
     writePin(BRAKING_PIN, 0);
    }
    sprintf(buffer, "%u", term_speed);
    initFile(MAIN_THROTTLE_FILE, buffer, &MAIN_THROTTLE_MUTEX);
    tach->calibrateToNeutral();
    break;
   case 'l':
    //left
    initFile(MAIN_STEERING_FILE, "60", &MAIN_STEERING_MUTEX);
    break;
   case 'r':
    //right
    initFile(MAIN_STEERING_FILE, "120", &MAIN_STEERING_MUTEX);
    break;
   case 'p':
    {
     unsigned throttle = readFile< unsigned >(MAIN_THROTTLE_FILE, "%u", &MAIN_THROTTLE_MUTEX);
     unsigned steering = readFile< unsigned >(MAIN_STEERING_FILE, "%u", &MAIN_STEERING_MUTEX);
     printf("Throttle: %u\n Steering: %u\n", throttle, steering);
     /*debugln(std::string("Throttle: ") +
             toString< unsigned >(throttle, "%u") +
             std::string("\nSteering: ") +
             toString< unsigned >(steering, "%u"));
    */}
    break;
   case 's':
    //straight
    initFile(MAIN_STEERING_FILE, "90", &MAIN_STEERING_MUTEX);
    break;
   case '=':
    //increment speed slowly (+10)
    term_speed += 10;
    if(term_speed >= 2000)
    {
     term_speed = 2000;
    }
    printf("Speed pulse width now %u\n", term_speed);
    /*debugln(std::string("Speed pulse width now ") +
            toString< unsigned >(term_speed, "%u"));
   */ break;
   case '-':
    //decrement speed slowly (-10)
    term_speed -= 10;
    if(term_speed <= 1600)
    {
     term_speed = 1600;
    }
    printf("Speed pulse width now %u\n", term_speed);
    /*debugln(std::string("Speed pulse width now ") +
            toString< unsigned >(term_speed, "%u"));
    */break;
   case 'e':
    //emergency
    {
     unsigned pinVal = readPin(EMERGENCY_GPIO);
     writePin(EMERGENCY_GPIO, 1 - pinVal);
     initFile(MAIN_THROTTLE_FILE, "1600", &MAIN_THROTTLE_MUTEX);
     printf("Emergency pin now %u [%sengaged]\n", 1 - pinVal, pinVal==1 ? "dis" : "");
     /*debugln(std::string("Emergency pin now ") +
            toString< unsigned >(1 - pinVal, "%u") +
            std::string(pinVal == 1 ? "[disengaged]" : "[engaged]"));
    */}
    break;
   case 't':
    //show tach info
    printf("[TACH]:{\nRPM:\t\t%lf\nOdometer:\t%lf\nAVG RPM:\t%lf\nRevs:\t%u\nReading:\t%s\n}\n", tach->rpm, tach->odometer, tach->avg_rpm, tach->revolutions, tach->running == 1 ? "TRUE": "FALSE");
    /*debugln("[TACH]:{");
    debugln(std::string("RPM:\t\t") +
            toString< double >(tach->rpm, "%lf"));
    debugln(std::string("Odometer:\t\t") +
            toString< double >(tach->odometer, "%lf"));
    debugln(std::string("AVG RPM:\t") +
            toString< double >(tach->avg_rpm, "%lf"));
    debugln(std::string("Revs:\t") +
            toString< unsigned >(tach->revolutions, "%u"));
    debugln(std::string("Reading:\t") + std::string(toString(tach->running)));
    debugln("}");
    */break;
   case '0':
   case 'q':
    run_main = 0;
    break;
   default:
    std::string msg = arduino.next();
    if(msg != "")
    {
     printf("[SERIAL]: \'%s\'\n", msg.c_str());
     //debugln(std::string("[SERIAL]: \'") + msg + std::string("\'"));
    }
    break;
  }
  unsigned camera_stop = readFile< unsigned >(CAMERA_FILE, "%u", &CAMERA_MUTEX);
  unsigned throttle = readFile< unsigned >(MAIN_THROTTLE_FILE, "%u", &MAIN_THROTTLE_MUTEX);
  if(camera_stop > 0 && !checkBrake() && tach->avg_rpm > 1.0)
  {
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
   printf("Camera demands brake: %d; throt=%d\n", camera_stop, throttle);
    pthread_mutex_lock(&brake_mutex);
    brake_commanded = false;
    brake_disengaged = true;
    pthread_mutex_unlock(&brake_mutex);
   writePin(BRAKING_PIN, 0);
   hardBrake();
   //debugln("Camera demands brake");
   usleep(10000);
   continue;
  }
  usleep(100000);
 }
 if(tach)
  delete tach;
 if(keyboard)
  delete keyboard;
 printf("Disabling arduino read and write\n");
 //debugln("Disabling arduino read and write");
 arduino.running[0] = 0;
 arduino.running[1] = 0;
 printf("Terminating arduino read thread by force\n");
 //debugln("Terminating arduino read thread by force");
 serial_read.cancel();
 serial_write.await();
 return 0;
}







bool checkBrake()
{
 bool output = false;
 pthread_mutex_lock(&brake_mutex);

 output = brake_commanded;

 pthread_mutex_unlock(&brake_mutex);
 return output;
}






void hardBrake(void* args)
{
 printf("Brake thread locks mutex\n");
 //debugln("Brake thread locks mutex");
 pthread_mutex_lock(&brake_mutex);
 if(brake_commanded)
 {
  printf("Already braking... unlock mutex\n");
  //debugln("Already braking... unlock mutex");
  pthread_mutex_unlock(&brake_mutex);
  return;
//  pthread_exit(NULL);
 }
 printf("We're braking... unlock mutex\n");
 //debugln("We're braking... unlock mutex");
 brake_commanded = true;
 brake_disengaged = false;
 pthread_mutex_unlock(&brake_mutex);

 writePin(BRAKING_PIN, 1);

 printf("Hard braking\n");
 //debugln("Hard braking");
 unsigned initial_speed = readFile<unsigned>(MAIN_THROTTLE_FILE, "%u", &MAIN_THROTTLE_MUTEX);
/* FILE* fp = fopen(MAIN_THROTTLE_FILE, "r");
 fscanf(fp, "%u", &initial_speed);
 fclose(fp);*/

 bool moving_forward = (initial_speed > 1600);
 bool moving_reverse = (initial_speed < 1600);
 printf("Initial speed: %u\nMoving forward: %s\nMoving reverse: %s\n",
  initial_speed,
  moving_forward ? "TRUE" : "FALSE",
  moving_reverse ? "TRUE" : "FALSE");
 /*debugln(std::string("Initial speed: ") +
         toString< unsigned >(initial_speed, "%u"));
 debugln(std::string("Moving forward: ") + toString(moving_forward));
 debugln(std::string("Moving reverse: ") + toString(moving_reverse));
*/
 if((tach->rpm < 1.0 && tach->avg_rpm < 1.0) && (!moving_forward && !moving_reverse))
 {
  printf("Car is immobile.\n");
  //debugln("Car is immobile.\n");

//  thread neutralThread(goNeutral);
//  neutralThread.await();

//  pthread_exit(NULL);
  return;
 }

 static int trial = 0;
 TIMER brakeTimer;
 initTimer(&brakeTimer);
 while(millis(&brakeTimer) < 2000 && tach->rpm > 30.0 && readPin(BRAKING_PIN) == 1)
 {
  if(moving_forward)
  {
   initFile(MAIN_THROTTLE_FILE, "1000", &MAIN_THROTTLE_MUTEX);
  } else {
   initFile(MAIN_THROTTLE_FILE, "2000", &MAIN_THROTTLE_MUTEX);
  }
 }

 printf("Finished braking\n");
 //debugln("Finished braking");
// pthread_exit(NULL);
}




void goNeutral(void* args)
{
 printf("Neutral thread locks mutex\n");
 //debugln("Neutral thread locks mutex");
 pthread_mutex_lock(&brake_mutex);
 if(brake_commanded)
 {
  printf("Already neutral... unlock mutex\n");
  //debugln("Already neutral... unlock mutex");
  pthread_mutex_unlock(&brake_mutex);
 // pthread_exit(NULL);
  return;
 }
 printf("We're going neutral... unlock mutex\n");
 //debugln("We're going neutral... unlock mutex");
 brake_commanded = true;
 brake_disengaged = false;
 pthread_mutex_unlock(&brake_mutex);
 writePin(BRAKING_PIN, 1);

 printf("Going neutral\n");
 //debugln("Going neutral");
 initFile(MAIN_THROTTLE_FILE, "1600", &MAIN_THROTTLE_MUTEX);

 printf("Finished going to neutral\n");
// pthread_exit(NULL);
}




const char* toString(bool value)
{
 return value ? "true" : "false";
}



template<class Type>
std::string toString(Type value, const char* type)
{
 char output[512];

 sprintf(output, type, value);

 return std::string(output);
}



void debug(std::string data)
{
// writeFile(DEBUG_FILE, data.c_str(), &DEBUG_MUTEX);
}
void debugln(std::string data)
{
// data += "\n";
// writeFile(DEBUG_FILE, data.c_str(), &DEBUG_MUTEX);
}




void initFile(const char* path, const std::string data, pthread_mutex_t* mutex)
{
 if(mutex)
  pthread_mutex_lock(mutex);

// printf("Writing to %s: \'%s\'\n", path, data.c_str());
 FILE* fp = fopen(path, "w");
 fprintf(fp, "%s", data.c_str());
 fclose(fp);

 if(mutex)
  pthread_mutex_unlock(mutex);
}



void writeFile(const char* path, const std::string data, pthread_mutex_t* mutex)
{
 if(data.c_str() == "") return; //don't waste clock cycles
 if(mutex)
  pthread_mutex_lock(mutex);

 if(FILE* fp = fopen(path, "r"))
 {
  fclose(fp);
  if(data == "" || data == "\n")
  {
   if(mutex)
    pthread_mutex_unlock(mutex);
   return;
  }
  fp = fopen(path, "a");
  fprintf(fp, "%s", data.c_str());
 } else if(data != "" && data != "\n") {
  initFile(path, data);
 }

 if(mutex)
  pthread_mutex_unlock(mutex);
}

template <class Type>
Type readFile(const char* path, const char* type, pthread_mutex_t* mutex)
{
 Type output;
 if(mutex)
  pthread_mutex_lock(mutex);

 //5 = read whole file into string
 if(FILE* fp = fopen(path, "r"))
 {
  fscanf(fp, type, &output);
//  char buffer[1024];
//  sprintf(buffer, "Read %s from %s\n", type, path);
//  printf(buffer, output);
  fclose(fp);
 }

 if(mutex)
  pthread_mutex_unlock(mutex);
 return output;
}







void initPin(jetsonGPIO pin, const char* sysfs, int direction)
{
 if(FILE* fp = fopen(sysfs, "r"))
 {
  fclose(fp);
  closePin(pin);
 }
 printf("Initializing pin %d as %s\n", pin, direction == 0 ? "INPUT" : "OUTPUT");
 //debugln(std::string("Initializing pin ") + toString< int >(pin, "%d") + std::string(direction == 0 ? " as INPUT" : " as OUTPUT"));
 gpioExport(pin);
 gpioSetDirection(pin, direction);
}
unsigned readPin(jetsonGPIO pin)
{
 unsigned output = 0;
 gpioGetValue(pin, &output);
 return output;
}
void writePin(jetsonGPIO pin, unsigned value)
{
 gpioSetValue(pin, value);
}
void closePin(jetsonGPIO pin)
{
 gpioUnexport(pin);
}

void initTimer(TIMER* timer)
{
 gettimeofday(timer, NULL);
}
double millis(TIMER* timer)
{
 TIMER end;
 initTimer(&end);

 double s = end.tv_sec - timer->tv_sec;
 double us = end.tv_usec - timer->tv_usec;

 double ms = ((s * 1000) + (us / 1000));
 return ms;
}
