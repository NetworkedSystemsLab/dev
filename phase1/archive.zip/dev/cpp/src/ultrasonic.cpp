#include "../include/main.h"
#include "../include/ultrasonic.h"

Sonar::Sonar(jetsonGPIO t, jetsonGPIO e):
 trigger(t),
 echo(e)
{

}
Sonar::~Sonar()
{

}

void Sonar::exportGPIO(void)
{
 gpioExport(trigger);
 gpioExport(echo);
}
void Sonar::unexportGPIO(void)
{
 gpioUnexport(trigger);
 gpioUnexport(echo);
}
void Sonar::setDirection(void)
{
 gpioSetDirection(trigger, outputPin);
 gpioSetDirection(echo, inputPin);
}
bool Sonar::triggerPing(void)
{
 unsigned int maxEcho = MAX_SENSOR_DISTANCE*ROUNDTRIP_CM + MAX_SENSOR_DELAY ;
 unsigned int echoValue = low ;
 // figure out duration of the pulse
 struct timeval tval_before, tval_after, tval_result;
 // Set trigger low to get ready to start
 gpioSetValue(trigger,low) ;
 usleep(4) ;
 // Pull trigger high for 10 microseconds to initiate echo location
 gpioSetValue(trigger,high) ;
 usleep(10) ;
 gpioSetValue(trigger,low) ;
 gettimeofday(&tval_before, NULL);
 gpioGetValue(echo,&echoValue) ;
 if (echoValue) {
  return false ;  // Previous echo not finished
 }
 while (echoValue != high) {
  gpioGetValue(echo,&echoValue) ;
  gettimeofday(&tval_after, NULL);
  timersub(&tval_after, &tval_before, &tval_result);
  if (tval_result.tv_usec > maxEcho) {
   return false ;
  }
 }
 return true;
}
unsigned int Sonar::ping(void)
{
   // trigger a ping, then wait for the echo
    if (!triggerPing()) {
        // Timed out ; No objects or objects too close to sensor to measure
        return NO_ECHO ;
    } else {
        unsigned int maxEcho = MAX_SENSOR_DISTANCE*ROUNDTRIP_CM + MAX_SENSOR_DELAY ;
        unsigned int echoValue = high ;
        // figure out duration of the pulse
        struct timeval tval_before, tval_after, tval_result;
        gettimeofday(&tval_before, NULL);
        while (echoValue != low) {
            gpioGetValue(echo,&echoValue) ;
            if (echoValue==low) {
                break;
            }

            gettimeofday(&tval_after, NULL);
            timersub(&tval_after, &tval_before, &tval_result);
            if (tval_result.tv_usec > maxEcho) {
                return NO_ECHO ;
            }
        }
        gettimeofday(&tval_after, NULL);
        timersub(&tval_after, &tval_before, &tval_result);
        // convert to microseconds
        // second conversion not necessary
        return tval_result.tv_sec*1000000+tval_result.tv_usec ;
    }
}
unsigned int Sonar::calculateMedian(int count, unsigned int sampleArray[]) {
    unsigned int tempValue ;
    int i,j ;   // loop counters
    for (i=0 ; i < count-1; i++) {
        for (j=0; j<count; j++) {
            if (sampleArray[j] < sampleArray[i]) {
                // swap elements
                tempValue = sampleArray[i] ;
                sampleArray[i] = sampleArray[j] ;
                sampleArray[j] = tempValue ;
            }
        }
    }
    if (count%2==0) {
        // if there are an even number of elements, return mean of the two elements in$
        return ((sampleArray[count/2] + sampleArray[count/2-1]) / 2.0) ;
    } else {
        // return the element in the middle
        return (sampleArray[count/2]) ;
    }
}
unsigned int Sonar::pingMedian(int iterations)
{
unsigned int pings[iterations] ;
    unsigned int lastPing ;
    int index = 0 ;
    int samples = iterations ;
    int cursor = 0 ;
    pings[0] = NO_ECHO ;
    while (index < iterations) {
        lastPing = ping() ;
        if (lastPing != NO_ECHO) {
            // Add this to the samples array
            pings[cursor] = lastPing ;
            cursor ++ ;
        } else {
            // Nothing detected, don't add to samples.
            samples -- ;
        }
        index ++ ;
        usleep(1000) ; // delay a millisecond between pings
    }
    // Figure out the median of the samples
    if (samples == 0) return NO_ECHO ;
    return calculateMedian(samples,pings);
}
