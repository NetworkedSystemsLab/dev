#ifndef __THREADS_H__
#define __THREADS_H__
#include "main.h"

class thread
{
private:
 pthread_t* _thread;
 void* (*_callback)(void*);
 void* _args;

public:
 bool _launched;
 thread();
 thread(void*(*cb)(void*), void* data=NULL);
 ~thread();

 thread& assign(void*(*cb)(void*), void* data=NULL);

 void launch();
 void await();
 void cancel();
 static void* null(void* args);
};

#endif

