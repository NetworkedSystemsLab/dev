#ifndef __MAIN_H__
#define __MAIN_H__

//***********************************
//***********************************
//
// Universal headers
//
//***********************************
//***********************************

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <errno.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <pthread.h>

#include <list>
#include <iostream>
#include <vector>
#include <string>

#include "jetsonTX2.h"

//***********************************
//***********************************
//
// Universal definitions
//
//***********************************
//***********************************

#define BAUD_RATE B9600

#define DEBUG_FILE "debug-log.txt"
extern pthread_mutex_t DEBUG_MUTEX;

#define CALIBRATE_REVOLUTIONS 40

#define DEV_TTY_USBMODEM "/dev/tty.usbmodemFD121" //for weird cables?
#define DEV_TTY_ACMX "/dev/ttyACM" //for the arduino, followed by an integer
#define DEV_TTY_USBX "/dev/ttyUSB" //for the pcb, followed by an integer

#define DIST_WHEEL_REV (4.41 * 3.14)
#define DIST_WHEEL_REV_CM (DIST_WHEEL_REV * 2.54)

extern pthread_mutex_t CAMERA_MUTEX;
#ifdef JETSON
#define CAMERA_FILE "../src/py/teleOp/slacker.txt"
#define MAIN_THROTTLE_FILE "../src/py/teleOp/main_throttle.txt"
#define MAIN_STEERING_FILE "../src/py/teleOp/main_steering.txt"
#else
#define CAMERA_FILE "slacker.txt"
#define MAIN_THROTTLE_FILE "main_throttle.txt"
#define MAIN_STEERING_FILE "main_steering.txt"
#endif

extern pthread_mutex_t MAIN_THROTTLE_MUTEX;
extern pthread_mutex_t MAIN_STEERING_MUTEX;

#define BRAKING_PIN pin23
#define BRAKING_PIN_SYSFS "/sys/class/gpio/gpio427/value"

#define EMERGENCY_GPIO pin33
#define EMERGENCY_GPIO_SYSFS "/sys/class/gpio/gpio389/value"

#define SONAR_0_ENABLED false
#define SONAR_0_TRIG pin7
#define SONAR_0_TRIG_SYSFS "/sys/class/gpio/gpio396/value"
#define SONAR_0_ECHO pin15
#define SONAR_0_ECHO_SYSFS "/sys/class/gpio/gpio255/value"

#define SONAR_1_ENABLED false
#define SONAR_1_TRIG pin18
#define SONAR_1_TRIG_SYSFS "/sys/class/gpio/gpio481/value"
#define SONAR_1_ECHO pin22
#define SONAR_1_ECHO_SYSFS "/sys/class/gpio/gpio254/value"

#define SONAR_2_ENABLED false
#define SONAR_2_TRIG pin29
#define SONAR_2_TRIG_SYSFS "/sys/class/gpio/gpio398/value"
#define SONAR_2_ECHO pin31
#define SONAR_2_ECHO_SYSFS "/sys/class/gpio/gpio298/value"

#define SONAR_3_ENABLED false
#define SONAR_3_TRIG pin21
#define SONAR_3_TRIG_SYSFS "/sys/class/gpio/gpio428/value"
#define SONAR_3_ECHO pin19
#define SONAR_3_ECHO_SYSFS "/sys/class/gpio/gpio429/value"

#define TACHOMETER pin13
#define TACHOMETER_SYSFS "/sys/class/gpio/gpio397/value"

#define TIMER struct timeval

//***********************************
//***********************************
//
// Universal function declarations
//
//***********************************
//***********************************

void hardBrake(void* args=NULL);
void goNeutral(void* args=NULL);

void initPin(jetsonGPIO pin, const char* sysfs, int direction);
unsigned readPin(jetsonGPIO pin);
void writePin(jetsonGPIO pin, unsigned value);
void closePin(jetsonGPIO pin);

void initTimer(TIMER* timer);
double millis(TIMER* timer);

void initFile(const char* path, const std::string data="", pthread_mutex_t* mutex=NULL);
void writeFile(const char* path, const std::string data="", pthread_mutex_t* mutex=NULL);

template<class Type>
Type readFile(const char* path, const char* type, pthread_mutex_t* mutex=NULL);

bool checkBrake();

const char* toString(bool value);

template<class Type>
std::string toString(Type value, const char* type);

void debug(std::string data);
void debugln(std::string data);

extern pthread_mutex_t brake_mutex;
extern bool brake_commanded;
extern bool brake_disengaged;
extern TIMER global_timer;
#endif

