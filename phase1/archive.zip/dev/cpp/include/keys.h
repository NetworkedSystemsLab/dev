#ifndef __KEYS_H__
#define __KEYS_H__

#include "main.h"
#include "threads.h"

class input
{
public:
 thread* _thread;
 std::vector<char> keys;

 input();
 ~input();

 char getKey();
 void flush();
 static void* poll(void* args);
};

#endif
