#include "jetsonTX2.h"

#ifndef __ULTRASONIC_H__
#define __ULTRASONIC_H__

#define MAX_SENSOR_DISTANCE 500
#define ROUNDTRIP_CM 58
#define MAX_SENSOR_DELAY 5800
#define NO_ECHO 0

class Sonar
{
public:
 jetsonGPIO trigger;
 jetsonGPIO echo;

 Sonar(jetsonGPIO t, jetsonGPIO e);
 ~Sonar();

 void exportGPIO(void);
 void unexportGPIO(void);
 void setDirection(void);
 bool triggerPing(void);
 unsigned int ping(void);
 unsigned int pingMedian(int iterations);
 unsigned int calculateMedian(int count, unsigned int sampleArray[]);
};

#endif
