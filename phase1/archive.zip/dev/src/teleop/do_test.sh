echo $1 > throttle.txt
sleep 2
echo 1000 > throttle.txt
sleep 5
echo 1600 > throttle.txt

