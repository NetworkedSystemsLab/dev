#define ACM0 "/dev/ttyACM0"
#define THROTTLE_FILE "throttle.txt"
#define STEERING_FILE "steering.txt"

#define THROTTLE_FULL_REVERSE 1000
#define THROTTLE_NEUTRAL 1600
#define THROTTLE_FULL_FORWARD 2000

#define STEERING_FULL_LEFT 60
#define STEERING_NEUTRAL 90
#define STEERING_FULL_RIGHT 120

#define MENU "Every module in 1! \n\nSelect a mode:\nPress [1] for teleop\nPress [2] for tachometer\nPress [3] for files\nPress [4] for delays\n\nPress [0] to quit\n> "
