#define TACHOMETER pin13
#define TACHOMETER_SYS_FS "/sys/class/gpio/gpio397/value"
