
########################################################################
#
# Copyright (c) 2017, STEREOLABS.
#
# All rights reserved.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
########################################################################

"""
    Live camera sample showing the camera information and video in real time and allows to control the different
    settings.
"""
#589,487
#242.584

import cv2
import pyzed.camera as zcam
import pyzed.types as tp
import pyzed.core as core
import pyzed.defines as sl
import numpy as np
import matplotlib.pyplot as plt
import math
import time

p=20
#i=2.5
i=0
#d=144
d =0 
index = 0
with open("pid.txt") as f:
    for line in f:
        numbers = list(map(float, line.split()))
        print(numbers)
        if(index==0):
            p=numbers[0]
        if(index==1):
            i=numbers[0]
        if(index==2):
            d=numbers[0]
        index += 1


#def plot(img):
 #   plt.imshow(img)
  #  plt.show()
   # cv2.waitKey(0)

    #f, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    #f.tight_layout()
    #ax1.imshow(img)
    #return


#def crop(img):
 #   im_height = img.shape[0]
#    im_len = img.shape[1]

    # resize = cv2.resize(frame, (int(im_len / 2), int(im_height / 2)), interpolation=cv2.INTER_LINEAR)
 #   out = img[0:int(im_height), 0:int(im_len / 2)]
    # out = out[0:120, 0:int((im_len / 4))] #comment out if ruler, bottom tape is not present
#    return out


def filter_region(image, vertices):
    """
    Create the mask using the vertices and apply it to the input image
    """
    mask = np.zeros_like(image)
    if len(mask.shape) == 2:
        cv2.fillPoly(mask, vertices, 255)
    else:
        cv2.fillPoly(mask, vertices, (255,) * mask.shape[2])  # in case, the input image has a channel dimension
    return cv2.bitwise_and(image, mask)


def select_region1(image):
    """
    It keeps the region surrounded by the `vertices` (i.e. polygon).  Other area is set to 0 (black).
    """
    # first, define the polygon by vertices
    rows, cols = image.shape[:2]
    bottom_left = [cols * 0.1, rows * 0.99]
    top_left = [cols * 0.2, rows * 0.6]
    bottom_right = [cols * 0.95, rows * 0.99]
    top_right = [cols * 0.8, rows * 0.6]
    # the vertices are an array of polygons (i.e array of arrays) and the data type must be integer
    vertices = np.array([[bottom_left, top_left, top_right, bottom_right]], dtype=np.int32)
    return filter_region(image, vertices)


def blur(img):
    k1 = 1
    k2 = 3
    blur = cv2.GaussianBlur(img, (k1, k2), 0)
    return blur



def warp(img):
    img_size = (img.shape[1], img.shape[0])
    img_len = img.shape[1]
    img_height = img.shape[0]

    rows, cols = img.shape[:2]
    bl = [cols * 0.3, rows * 0.99]
    tl = [cols * 0.45, rows * 0.65]
    br = [cols * 0.7, rows * 0.99]
    tr = [cols * 0.55, rows * 0.65]

    src = np.float32(
        [
            tr, \
            br, \
            bl, \
            tl])
    dst = np.float32(  # dest points
        [
            [int(img_len * (7 / 10)) - 100, 0],
            [int(img_len * (6 / 10)), img_height],
            [int(img_len * (2 / 10)), img_height],
            [int(img_len * (3 / 10)) - 100, 0]
        ])
    #print('persp transform', time.time())
    # persp xform src points to dest points

    mat_inv = cv2.getPerspectiveTransform(src, dst)
    unwarped = cv2.warpPerspective(img, mat_inv, img_size, flags=cv2.INTER_LINEAR)
    return unwarped



def offset_write(offset_arr,i):
    if (i==1):
        #print(offset_arr)
        output = np.mean(offset_arr)
        print(output)
        #time.sleep(.005)
        follow(output)
        i = 0
    return i


camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_BRIGHTNESS
str_camera_settings = "BRIGHTNESS"
step_camera_settings = 1



def main():

    #print("Running...")
    init = zcam.PyInitParameters()
    init.camera_resolution = sl.PyRESOLUTION.PyRESOLUTION_VGA 
    init.camera_fps = 100 
    
    cam = zcam.PyZEDCamera()
    if not cam.is_opened():
        print("Opening ZED Camera...")
    status = cam.open(init)
    if status != tp.PyERROR_CODE.PySUCCESS:
        print(repr(status))
        exit()

    runtime = zcam.PyRuntimeParameters()
    mat = core.PyMat()

    print_camera_information(cam)
    print_help()
    i=0

    offset_arr = []
    stop_count = 0

    key = ''
    while(1):  # for 'q' key
        #print('start', time.time())
        err = cam.grab(runtime)
        if err == tp.PyERROR_CODE.PySUCCESS:
            cam.retrieve_image(mat, sl.PyVIEW.PyVIEW_LEFT)

            frame = mat.get_data() #raw input image is stored in "frame"
            print('frame retrieve', time.time())
 
            
            i = offset_write(offset_arr, i)
            if (i==0):
                offset_arr = []
 
            #im_len = frame.shape[1]
            #im_height = frame.shape[0]
            #print(im_len,im_height) ##print frame size

            #undist_img = frame #for calling later to view undistorted input

            img = select_region1(frame) # mask region by space
            #warped_img = warp(img)          # uncomment to view perspective t-form on normal image
     
            #print('select region', time.time())

            #img = blur(img)
            #print('blur', time.time())

	    #RGBD masking for tape color, creates binary image
#white
      #      lower_red = np.array([120,0,100, 255])
       #     upper_red = np.array([255,255,255, 255])
        #    mask = cv2.inRange(img, lower_red, upper_red)  

#lab blue
            lower_red = np.array([160,0,0, 255])
            upper_red = np.array([255,190,95, 255])
            mask = cv2.inRange(img, lower_red, upper_red)  
            #print('color mask', time.time())
#test blue
            #lower_red = np.array([180,100,0, 255])
            #upper_red = np.array([255,190,95, 255])
            #mask = cv2.inRange(img, lower_red, upper_red)  

#hallway blue
            #lower_red = np.array([100,0,0, 255])
            #upper_red = np.array([255,190,95, 255])
            #mask = cv2.inRange(img, lower_red, upper_red) 

            #perspective tform on binary image, canny edge detection for clean lines
            warped_mask = warp(mask)
            #warped_mask = cv2.Canny(warped_mask, 5, 15, apertureSize=3)
     
            
            # metric distance / pixel conversion factor
            #ym_per_pix = 7.62 / 50  # cm per pixel in y dimension
            xm_per_pix = 3.5 / 70  # cm per pixel in x dimension

            


            

#            top_slice = (warped_mask[int(warped_mask.shape[0] * 7 / 10):int(warped_mask.shape[0] * 8/10), :])
 #           nonzero_slice_top = top_slice.nonzero()
  #          nonzerox_slice_top = np.array(nonzero_slice_top[1])
   #         if (not np.any(nonzerox_slice_top)):
    #            stop_count += 1
     #           if(stop_count > 50):
      #              stop()
       #         continue



            bottom_slice = (warped_mask[int(warped_mask.shape[0] * 9 / 10):warped_mask.shape[0], :])
            nonzero_slice = bottom_slice.nonzero()
            nonzerox_slice = np.array(nonzero_slice[1])
            if (not np.any(nonzerox_slice)):
                stop_count += 1
                if(stop_count > 75):
                    #print(stop_count)
                    stop()
                    stop_count = 0
                continue
            operate()
            left_line_int = np.min(nonzerox_slice)
            right_line_int = np.max(nonzerox_slice)
            position = (left_line_int + right_line_int) / 2
            # Follow with the left side of the front-left wheel on right edge of line 
            offset = (int(warped_mask.shape[1]) / 2 - position ) * xm_per_pix #+ 13
            #cv2.circle(warped_mask, (int(position), warped_mask.shape[0]), 10, 255, 3)

            #print('computing offsest', time.time())

            
 
            #cv2.imshow('frame', img)
            offset_arr.append(offset)
            if((right_line_int - left_line_int) > 250 ):
                continue
 
            i = i+1
            #print('append offset array', time.time())
            #key = cv2.waitKey(5)
            #settings(key, cam, runtime, mat)
            cv2.imshow('frame', warped_mask)
            key = cv2.waitKey(5)
            settings(key, cam, runtime, mat)
        else:
            key = cv2.waitKey(5)
    cv2.destroyAllWindows()

    cam.close()

    #print("\nFINISH")


def print_camera_information(cam):
    print("Resolution: {0}, {1}.".format(round(cam.get_resolution().width, 2), cam.get_resolution().height))
    print("Camera FPS: {0}.".format(cam.get_camera_fps()))
    print("Firmware: {0}.".format(cam.get_camera_information().firmware_version))
    print("Serial number: {0}.\n".format(cam.get_camera_information().serial_number))


def print_help():
    print("Help for camera setting controls")
    print("  Increase camera settings value:     +")
    print("  Decrease camera settings value:     -")
    print("  Switch camera settings:             s")
    print("  Reset all parameters:               r")
    print("  Record a video:                     z")
    print("  Quit:                               q\n")


def settings(key, cam, runtime, mat):
    if key == 115:  # for 's' key
        switch_camera_settings()
    elif key == 43:  # for '+' key
        current_value = cam.get_camera_settings(camera_settings)
        cam.set_camera_settings(camera_settings, current_value + step_camera_settings)
        #print(str_camera_settings + ": " + str(current_value + step_camera_settings))
    elif key == 45:  # for '-' key
        current_value = cam.get_camera_settings(camera_settings)
        if current_value >= 1:
            cam.set_camera_settings(camera_settings, current_value - step_camera_settings)
            #print(str_camera_settings + ": " + str(current_value - step_camera_settings))
    elif key == 114:  # for 'r' key
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_BRIGHTNESS, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_CONTRAST, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_HUE, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_SATURATION, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_GAIN, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_EXPOSURE, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_WHITEBALANCE, -1, True)
        #print("Camera settings: reset")
    elif key == 122:  # for 'z' key
        record(cam, runtime, mat)


def switch_camera_settings():
    global camera_settings
    global str_camera_settings
    if camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_BRIGHTNESS:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_CONTRAST
        str_camera_settings = "Contrast"
        #print("Camera settings: CONTRAST")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_CONTRAST:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_HUE
        str_camera_settings = "Hue"
        #print("Camera settings: HUE")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_HUE:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_SATURATION
        str_camera_settings = "Saturation"
        #print("Camera settings: SATURATION")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_SATURATION:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_GAIN
        str_camera_settings = "Gain"
        #print("Camera settings: GAIN")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_GAIN:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_EXPOSURE
        str_camera_settings = "Exposure"
        #print("Camera settings: EXPOSURE")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_EXPOSURE:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_WHITEBALANCE
        str_camera_settings = "White Balance"
        #print("Camera settings: WHITEBALANCE")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_WHITEBALANCE:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_BRIGHTNESS
        str_camera_settings = "Brightness"
        #print("Camera settings: BRIGHTNESS")






input_file="../livelanedet/offset.txt"
output_file="../teleOp/main_steering.txt"
throttle_file = "../teleOp/slacker.txt"


def PID(CTE):    
    integral=0
    derivative=0
    prevCTE=0
    integral+=CTE
    if prevCTE==0:
        prevCTE=CTE
    derivative=(CTE-prevCTE)
    prevCTE=CTE

#for resetting or limiting output
#        if abs(self.integral)>=50: #reset integral 
#            self.integral=0
#        if abs(self.derivative)>CTE*.60: limit derivative
#            self.derivative=CTE*.50
    print('compute PID', time.time())
    angle=-p*CTE-d*derivative-integral*i
    return angle


def follow(offset): 
    prevoffset=0
       
    if prevoffset!=offset:

        #print(offset)
        prevoffset=offset
        steer=PID(offset)
        maxangle=37
        steering = math.floor(steer*30/maxangle+90)

        if steering>120:
            steering=120
        if steering<60:
            steering=60
        print(steering)
        print(time.time())
        F=open("monitor_pid.txt", "a")
        F.write('{}\n'.format(steering))
        F=open(output_file,"w")
        F.write('{}'.format(steering))
        print('write steering to file', time.time())
        F.close()

def operate():
    brake = 0
    stop_count = 0
    F=open(throttle_file,"w")
    F.write('{}'.format(brake))
    print('write steering to file', time.time())
    F.close()


def stop():
    brake = 666
    print('LINE LOST')
    F=open(throttle_file,"w")
    F.write('{}'.format(brake))
    F.close()
    time.sleep(1)
    stop_count = 0



if __name__ == "__main__":
    main()
#select region 1523468221.4658015

#write steering to file 1523468224.078495
#write steering to file 1523468224.078495
#write steering to file 1523468224.078495
#write steering to file 1523468224.078495
#write steering to file 1523468224.078495
#write steering to file 1523468224.078495
#write steering to file 1523468224.078495
#write steering to file 1523468224.078495
#write steering to file 1523468224.078495
#write steering to file 1523468224.078495
#write steering to file 1523468224.078495
#write steering to file 1523468224.078495
#write steering to file 1523468224.078495















