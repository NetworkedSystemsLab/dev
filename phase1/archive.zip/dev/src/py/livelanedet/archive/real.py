#import pickle
import cv2
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import pyzed.camera as zcam
import pyzed.defines as sl
import pyzed.types as tp
import pyzed.core as core
#import imutils




def plot(img):
    plt.imshow(img)
    plt.show()
    cv2.waitKey(0)

    f, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    f.tight_layout()
    ax1.imshow(img)
    return


def crop(img):
    im_height = img.shape[0]
    im_len = img.shape[1]

    # resize = cv2.resize(frame, (int(im_len / 2), int(im_height / 2)), interpolation=cv2.INTER_LINEAR)
    out = img[0:int(im_height), 0:int(im_len / 2)]
    # out = out[0:120, 0:int((im_len / 4))] #comment out if ruler, bottom tape is not present
    return out


def filter_region(image, vertices):
    """
    Create the mask using the vertices and apply it to the input image
    """
    mask = np.zeros_like(image)
    if len(mask.shape) == 2:
        cv2.fillPoly(mask, vertices, 255)
    else:
        cv2.fillPoly(mask, vertices, (255,) * mask.shape[2])  # in case, the input image has a channel dimension
    return cv2.bitwise_and(image, mask)


def select_region1(image):
    """
    It keeps the region surrounded by the `vertices` (i.e. polygon).  Other area is set to 0 (black).
    """
    # first, define the polygon by vertices
    rows, cols = image.shape[:2]
    bottom_left = [cols * 0.3, rows * 0.99]
    top_left = [cols * 0.3, rows * 0.6]
    bottom_right = [cols * 0.8, rows * 0.99]
    top_right = [cols * 0.7, rows * 0.6]
    # the vertices are an array of polygons (i.e array of arrays) and the data type must be integer
    vertices = np.array([[bottom_left, top_left, top_right, bottom_right]], dtype=np.int32)
    return filter_region(image, vertices)


def blur(img):
    k1 = 3
    k2 = 9
    blur = cv2.GaussianBlur(img, (k1, k2), 0)
    return blur



def warp(img):
    img_size = (img.shape[1], img.shape[0])
    img_len = img.shape[1]
    img_height = img.shape[0]

    rows, cols = img.shape[:2]
    bl = [cols * 0.3, rows * 0.99]
    tl = [cols * 0.45, rows * 0.65]
    br = [cols * 0.7, rows * 0.99]
    tr = [cols * 0.55, rows * 0.65]

    src = np.float32(
        [
            tr, \
            br, \
            bl, \
            tl])
    dst = np.float32(  # dest points
        [
            [int(img_len * (7 / 10)) - 100, 0],
            [int(img_len * (6 / 10)), img_height],
            [int(img_len * (2 / 10)), img_height],
            [int(img_len * (3 / 10)) - 100, 0]
        ])
    # persp xform src points to dest points

    mat_inv = cv2.getPerspectiveTransform(src, dst)
    unwarped = cv2.warpPerspective(img, mat_inv, img_size, flags=cv2.INTER_LINEAR)
    return unwarped


def offset_write(offset_arr,i):
    if (i==5):
        #print(offset_arr)
        output = np.mean(offset_arr)
        #print(output)

        f = open('offset.txt', 'w')  # w : writing mode  /  r : reading mode  /  a  :  appending mode
        f.write('{}'.format(output))
        f.close()
        i = 0
    return i


def capframe():
    # Create a PyZEDCamera object
    zed = zcam.PyZEDCamera()

    # Create a PyInitParameters object and set configuration parameters
    init_params = zcam.PyInitParameters()
    init_params.camera_resolution = sl.PyRESOLUTION.PyRESOLUTION_HD1240  # Use HD1240 video mode
    init_params.camera_fps = 30  # Set fps at 30

    # Open the camera
    err = zed.open(init_params)
    if err != tp.PyERROR_CODE.PySUCCESS:
        print("error")
        exit(1)

    # Capture 1 frame and stop
    i = 0
    image = core.PyMat()
    while i < 1:
        # Grab an image, a PyRuntimeParameters object must be given to grab()
        if zed.grab(zcam.PyRuntimeParameters()) == tp.PyERROR_CODE.PySUCCESS:
            # A new image is available if grab() returns PySUCCESS
            zed.retrieve_image(image, sl.PyVIEW.PyVIEW_LEFT)
            timestamp = zed.get_timestamp(sl.PyTIME_REFERENCE.PyTIME_REFERENCE_CURRENT)  # Get the timestamp at the time the image was captured
            cv2.imshow("Tyler", image.get_data())
            i = i + 1
            frame = image.get_data()
    # Close the camera
    zed.close()
    return frame





#cap = cv2.VideoCapture('test.avi')
i=0
offset_arr = []

#while (cap.isOpened()):
while (True):

    i = offset_write(offset_arr, i)
    if (i==0):
        offset_arr = []

    #ret, frame = cap.read()
    frame = capframe()

    im_height = frame.shape[0]
    im_len = frame.shape[1]

    undist_img = crop(frame)
    img = select_region1(undist_img)
    warped_img = warp(img)


    lower_red = np.array([140, 180, 180])
    upper_red = np.array([255, 255, 255])
    mask = cv2.inRange(img, lower_red, upper_red)


    warped_mask = warp(mask)
    warped_mask = cv2.Canny(warped_mask, 5, 15, apertureSize=3)
    warp_len = warped_mask.shape[1]
    # print(warp_len)

    # lines1 = cv2.HoughLinesP(warped_mask, rho=2, theta=np.pi / 60, threshold=150, minLineLength=50, maxLineGap=500)
    # for line in lines1:
    #     #print(line)
    #     for x1, y1, x2, y2 in line:
    #         cv2.line(warped_img, (x1, y1), (x2, y2), 255, 3)

    histogram = np.sum(warped_mask[int(warped_mask.shape[0] * 8 / 10):, :], axis=0)  # histogram oh bottom half
    out_img = np.dstack((warped_mask, warped_mask, warped_mask)) * 255  # output image


    # Find the peak of the left and right halves of the histogram
    # These will be the starting point for the left and right lines
    midpoint = np.int(histogram.shape[0] / 2)
    leftx_base = np.argmax(histogram[:midpoint])
    rightx_base = np.argmax(histogram[midpoint:]) + midpoint
    if (leftx_base == 0):
        leftx_base = midpoint  + np.argmax(histogram[int(midpoint):rightx_base])
    if (rightx_base == int(warped_mask.shape[1]/2)):
        rightx_base = np.argmax(histogram[:midpoint])
    #print(leftx_base,rightx_base)
    # Choose the number of sliding windows
    nwindows = 15
    # Set height of windows
    window_height = np.int(warped_mask.shape[0] / nwindows)
    # Identify the x and y positions of all nonzero pixels in the image
    nonzero = warped_mask.nonzero()
    nonzeroy = np.array(nonzero[0])
    nonzerox = np.array(nonzero[1])
    # Current positions to be updated for each window
    leftx_current = leftx_base
    rightx_current = rightx_base
    # Set the width of the windows +/- margin
    margin = 25
    # Set minimum number of pixels found to recenter window
    minpix = 5
    # Create empty lists to receive left and right lane pixel indices
    left_lane_inds = []
    right_lane_inds = []

    for window in range(nwindows):
        # Identify window boundaries in x and y (and right and left)
        win_y_low = warped_mask.shape[0] - (window + 1) * window_height
        win_y_high = warped_mask.shape[0] - window * window_height
        win_xleft_low = leftx_current - margin
        win_xleft_high = leftx_current + margin

        win_xright_low = rightx_current - margin
        win_xright_high = rightx_current + margin
        # Draw the windows on the visualization image
        # cv2.rectangle(warped_mask, (win_xleft_low, win_y_low), (win_xleft_high, win_y_high),
        #               (160, 101, 101), 2)
        # cv2.rectangle(warped_mask, (win_xright_low, win_y_low), (win_xright_high, win_y_high),
        #               (160, 101, 101), 2)
        # Identify the nonzero pixels in x and y within the window
        good_left_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) &
                          (nonzerox >= win_xleft_low) & (nonzerox < win_xleft_high)).nonzero()[0]
        good_right_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) &
                           (nonzerox >= win_xright_low) & (nonzerox < win_xright_high)).nonzero()[0]
        # Append these indices to the lists
        left_lane_inds.append(good_left_inds)
        right_lane_inds.append(good_right_inds)
        # If you found > minpix pixels, recenter next window on their mean position
        if len(good_left_inds) > minpix:
            leftx_current = np.int(np.mean(nonzerox[good_left_inds]))
        if len(good_right_inds) > minpix:
            rightx_current = np.int(np.mean(nonzerox[good_right_inds]))
            # if nwindows == 30:
            # topx = (leftx_current + rightx_current)/2
            # print('topx =',topx)
            # cv2.circle(warped_mask, (int(topx), 5), 5, (160, 101, 101), 2)

    # Concatenate the arrays of indices
    left_lane_inds = np.concatenate(left_lane_inds)
    right_lane_inds = np.concatenate(right_lane_inds)

    # Extract left and right line pixel positions
    leftx = nonzerox[left_lane_inds]
    lefty = nonzeroy[left_lane_inds]


    rightx = nonzerox[right_lane_inds]
    righty = nonzeroy[right_lane_inds]

    # Fit a second order polynomial to each
    # if(not np.any(leftx)):
    #     continue
    # if(not np.any(rightx)):
    #     continue
    left_fit = np.polyfit(lefty, leftx, 2)
    right_fit = np.polyfit(righty, rightx, 2)

    # Generate x and y values for plotting
    ploty = np.linspace(0, warped_mask.shape[0] - 1, warped_mask.shape[0])  # generates arrayy of 0 to
    left_fitx = left_fit[0] * ploty ** 2 + left_fit[1] * ploty + left_fit[2]
    right_fitx = right_fit[0] * ploty ** 2 + right_fit[1] * ploty + right_fit[2]
    # Rad of curve

    ym_per_pix = 7.62 / 50  # cm per pixel in y dimension
    xm_per_pix = 3.5 / 70  # cm per pixel in x dimension




    # Calculate the new radii of curvature
    y_eval = np.min(ploty)
    left_curverad = ((1 + (2 * left_fit[0] * y_eval*ym_per_pix + left_fit[1]) ** 2) ** 1.5) / np.absolute(2 * left_fit[0])
    right_curverad = ((1 + (2 * right_fit[0] * y_eval*ym_per_pix + right_fit[1]) ** 2) ** 1.5) / np.absolute(2 * right_fit[0])
    curverad = (left_curverad+right_curverad)/2


    #YAW ANGLE
    slopes = []
    for y_eval in range(0,int(np.max(ploty)*.6),50):
        left_slope =  2 * left_fit[0] * y_eval * ym_per_pix + left_fit[1]
        right_slope = 2 * right_fit[0] * y_eval * ym_per_pix + left_fit[1]
        slope = (left_slope + right_slope)/2
        slopes.append(slope)
    slope = np.mean(slopes)
    inv_yaw = (slope)
    yaw_angle = np.arctan(inv_yaw)*(180/np.pi)


    # plt.ion()
    # mark_size = 3
    #
    # plt.xlim(0, 1280)
    # plt.ylim(0, 720)
    #
    # plt.plot(left_fitx, ploty, color='red', linewidth=3)
    # plt.plot(right_fitx, ploty, color='green', linewidth=3)
    # plt.gca().invert_yaxis()
    # plt.pause(0.05)

    # Finding Center position by averaging x values of each lane

    bottom_slice = (warped_mask[int(warped_mask.shape[0] * 9.5 / 10):warped_mask.shape[0], :])
    nonzero_slice = bottom_slice.nonzero()
    nonzerox_slice = np.array(nonzero_slice[1])
    left_line_int = np.min(nonzerox_slice)
    right_line_int = np.max(nonzerox_slice)
    position = (left_line_int + right_line_int) / 2

    offset = (warp_len / 2 - position) * xm_per_pix
    cv2.circle(warped_mask, (int(position), warped_mask.shape[0]), 10, 255, 3)


    #PRINTING
    font = cv2.FONT_HERSHEY_SIMPLEX
    out = undist_img

    text = 'Yaw Angle = {:.2f}(deg)'.format(yaw_angle)
    cv2.putText(out, text, (20, 200), font, 2, (255), 2)

    text = 'Offset = {:.2f}(cm)'.format(offset)
    cv2.putText(out, text, (20, 300), font, 2, (255), 2)

    text = 'Radius of Curvature = {:.2f}(cm)'.format(curverad)
    cv2.putText(out, text, (20, 60), font, 2, (255), 2)
    # Example values: 632.1 m    626.2 m


    # cv2.imshow('frame', overlayed)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

    cv2.imshow('test', undist_img)
    offset_arr.append(offset)
    i = i+1
    #print(i)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


#cap.release()
cv2.destroyAllWindows()


