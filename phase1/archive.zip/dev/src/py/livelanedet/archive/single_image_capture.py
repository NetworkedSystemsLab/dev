
import pyzed.camera as zcam
import pyzed.defines as sl
import pyzed.types as tp
import pyzed.core as core
import cv2

def main():
    # Create a PyZEDCamera object
    zed = zcam.PyZEDCamera()

    # Create a PyInitParameters object and set configuration parameters
    init_params = zcam.PyInitParameters()
    init_params.camera_resolution = sl.PyRESOLUTION.PyRESOLUTION_HD1240  # Use HD1240 video mode
    init_params.camera_fps = 30  # Set fps at 30

    # Open the camera
    err = zed.open(init_params)
    if err != tp.PyERROR_CODE.PySUCCESS:
        print("error")
        exit(1)

    # Capture 1 frame and stop
    i = 0
    image = core.PyMat()
    while i < 1:
        # Grab an image, a PyRuntimeParameters object must be given to grab()
        if zed.grab(zcam.PyRuntimeParameters()) == tp.PyERROR_CODE.PySUCCESS:
            # A new image is available if grab() returns PySUCCESS
            zed.retrieve_image(image, sl.PyVIEW.PyVIEW_LEFT)
            timestamp = zed.get_timestamp(sl.PyTIME_REFERENCE.PyTIME_REFERENCE_CURRENT)  # Get the timestamp at the time the image was captured
            cv2.imwrite("/home/nvidia/dev/src/py/livelanedet/Image{0}.jpg".format(timestamp), image.get_data())
            cv2.imshow("Tyler", image.get_data())
            i = i + 1

    # Close the camera
    zed.close()

if __name__ == "__main__":
    main()
