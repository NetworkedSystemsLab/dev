########################################################################
#
# Copyright (c) 2017, STEREOLABS.
#
# All rights reserved.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
########################################################################

"""
    Live camera sample showing the camera information and video in real time and allows to control the different
    settings.
"""
#589,487
#242.584

import cv2
import pyzed.camera as zcam
import pyzed.types as tp
import pyzed.core as core
import pyzed.defines as sl
import numpy as np
import matplotlib.pyplot as plt
import math
import serial, time


arduino = serial.Serial('/dev/ttyACM0', 9600, timeout=.1)
time.sleep(1) #allow the arduino to connect

def plot(img):
    plt.imshow(img)
    plt.show()
    cv2.waitKey(0)

    f, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
    f.tight_layout()
    ax1.imshow(img)
    return


def crop(img):
    im_height = img.shape[0]
    im_len = img.shape[1]

    # resize = cv2.resize(frame, (int(im_len / 2), int(im_height / 2)), interpolation=cv2.INTER_LINEAR)
    out = img[0:int(im_height), 0:int(im_len / 2)]
    # out = out[0:120, 0:int((im_len / 4))] #comment out if ruler, bottom tape is not present
    return out


def filter_region(image, vertices):
    """
    Create the mask using the vertices and apply it to the input image
    """
    mask = np.zeros_like(image)
    if len(mask.shape) == 2:
        cv2.fillPoly(mask, vertices, 255)
    else:
        cv2.fillPoly(mask, vertices, (255,) * mask.shape[2])  # in case, the input image has a channel dimension
    return cv2.bitwise_and(image, mask)


def select_region1(image):
    """
    It keeps the region surrounded by the `vertices` (i.e. polygon).  Other area is set to 0 (black).
    """
    # first, define the polygon by vertices
    rows, cols = image.shape[:2]
    bottom_left = [cols * 0.3, rows * 0.99]
    top_left = [cols * 0.3, rows * 0.6]
    bottom_right = [cols * 0.8, rows * 0.99]
    top_right = [cols * 0.7, rows * 0.6]
    # the vertices are an array of polygons (i.e array of arrays) and the data type must be integer
    vertices = np.array([[bottom_left, top_left, top_right, bottom_right]], dtype=np.int32)
    return filter_region(image, vertices)


def blur(img):
    k1 = 3
    k2 = 9
    blur = cv2.GaussianBlur(img, (k1, k2), 0)
    return blur



def warp(img):
    img_size = (img.shape[1], img.shape[0])
    img_len = img.shape[1]
    img_height = img.shape[0]

    rows, cols = img.shape[:2]
    bl = [cols * 0.3, rows * 0.99]
    tl = [cols * 0.45, rows * 0.65]
    br = [cols * 0.7, rows * 0.99]
    tr = [cols * 0.55, rows * 0.65]

    src = np.float32(
        [
            tr, \
            br, \
            bl, \
            tl])
    dst = np.float32(  # dest points
        [
            [int(img_len * (7 / 10)) - 100, 0],
            [int(img_len * (6 / 10)), img_height],
            [int(img_len * (2 / 10)), img_height],
            [int(img_len * (3 / 10)) - 100, 0]
        ])
    # persp xform src points to dest points

    mat_inv = cv2.getPerspectiveTransform(src, dst)
    unwarped = cv2.warpPerspective(img, mat_inv, img_size, flags=cv2.INTER_LINEAR)
    return unwarped



def offset_write(offset_arr,i):
    if (i==4):
        print(offset_arr)
        output = np.mean(offset_arr)
        print(output)
        follow(output)
        i = 0
    return i



camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_BRIGHTNESS
str_camera_settings = "BRIGHTNESS"
step_camera_settings = 1


def main():
    #print("Running...")
    init = zcam.PyInitParameters()
    cam = zcam.PyZEDCamera()
    if not cam.is_opened():
        print("Opening ZED Camera...")
    status = cam.open(init)
    if status != tp.PyERROR_CODE.PySUCCESS:
        print(repr(status))
        exit()

    runtime = zcam.PyRuntimeParameters()
    mat = core.PyMat()

    print_camera_information(cam)
    print_help()
    i=0
    offset_arr = []

    key = ''
    while key != 113:  # for 'q' key
        err = cam.grab(runtime)
        if err == tp.PyERROR_CODE.PySUCCESS:
            cam.retrieve_image(mat, sl.PyVIEW.PyVIEW_LEFT)
            frame = mat.get_data() #raw input image is stored in "frame"

            i = offset_write(offset_arr, i)
            if (i==0):
                offset_arr = []

            im_len = frame.shape[1]
            im_height = frame.shape[0]
            #print(im_len,im_height) ##print frame size

            undist_img = frame #for calling later to view undistorted input

            img = select_region1(undist_img) # mask region by space
            #warped_img = warp(img)          # uncomment to view perspective t-form on normal image

	    #RGBD masking for tape color, creates binary image
            lower_red = np.array([140, 180, 180, 255])
            upper_red = np.array([255, 255, 255, 255])
            mask = cv2.inRange(img, lower_red, upper_red)

            #perspective tform on binary image, canny edge detection for clean lines
            warped_mask = warp(mask)
            warped_mask = cv2.Canny(warped_mask, 5, 15, apertureSize=3)

            #take histogram of bottom 8/10th's of binary image to find the base of the lane relative to position:(center of image)
            histogram = np.sum(warped_mask[int(warped_mask.shape[0] * 8 / 10):, :], axis=0)


            # Find the peak of the left and right halves of the histogram
            # These will be the starting point for the left and right lines
            midpoint = np.int(histogram.shape[0] / 2)
            if (not np.any(histogram)): #no histogram present? - no lanes in image, retry next frame 
                continue

            # maximum vertical whitespace of left half and right half of histogram is the starting point of left or right lane line
            leftx_base = np.argmax(histogram[:midpoint])
            rightx_base = np.argmax(histogram[midpoint:]) + midpoint

	    # if lane edges are too far right, left line = right line
            if (leftx_base == 0):
                leftx_base = midpoint  + np.argmax(histogram[int(midpoint):rightx_base])
            # if lane edges are too far left, right line = left line
            if (rightx_base == int(warped_mask.shape[1]/2)):
                rightx_base = np.argmax(histogram[:midpoint])

            #print('historgram present')

            # Choose the number of sliding windows
            nwindows = 30
            # Set height of windows
            window_height = np.int(warped_mask.shape[0] / nwindows)
            # Identify the x and y positions of all nonzero pixels in the image
            nonzero = warped_mask.nonzero()
            nonzeroy = np.array(nonzero[0])
            nonzerox = np.array(nonzero[1])
            # Current positions to be updated for each window
            leftx_current = leftx_base
            rightx_current = rightx_base
            # Set the width of the windows +/- margin
            margin = 25
            # Set minimum number of pixels found to recenter window
            minpix = 5
            # Create empty lists to receive left and right lane pixel indices
            left_lane_inds = []
            right_lane_inds = []

            for window in range(nwindows):
                # Identify window boundaries in x and y (and right and left)
                win_y_low = warped_mask.shape[0] - (window + 1) * window_height
                win_y_high = warped_mask.shape[0] - window * window_height
                win_xleft_low = leftx_current - margin
                win_xleft_high = leftx_current + margin

                win_xright_low = rightx_current - margin
                win_xright_high = rightx_current + margin
                # Draw the windows on the visualization image
                cv2.rectangle(warped_mask, (win_xleft_low, win_y_low), (win_xleft_high, win_y_high),(160, 101, 101), 2)
                cv2.rectangle(warped_mask, (win_xright_low, win_y_low), (win_xright_high, win_y_high),(160, 101, 101), 2)
                # Identify the nonzero pixels in x and y within the window
                good_left_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) & (nonzerox >= win_xleft_low) & (nonzerox < win_xleft_high)).nonzero()[0]
                good_right_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) & (nonzerox >= win_xright_low) & (nonzerox < win_xright_high)).nonzero()[0]
                # Append these indices to the lists
                left_lane_inds.append(good_left_inds)
                right_lane_inds.append(good_right_inds)
                # If you found > minpix pixels, recenter next window on their mean position
                if len(good_left_inds) > minpix:
                    leftx_current = np.int(np.mean(nonzerox[good_left_inds]))
                if len(good_right_inds) > minpix:
                    rightx_current = np.int(np.mean(nonzerox[good_right_inds]))


            # Concatenate the arrays of indices
            left_lane_inds = np.concatenate(left_lane_inds)
            right_lane_inds = np.concatenate(right_lane_inds)

            # Extract left and right line pixel positions
            leftx = nonzerox[left_lane_inds]
            lefty = nonzeroy[left_lane_inds]

            rightx = nonzerox[right_lane_inds]
            righty = nonzeroy[right_lane_inds]

            # Fit a second order polynomial to each
            # no lines? try next frame
            if (not np.any(leftx)):
                continue
            if (not np.any(lefty)):
                continue
            left_fit = np.polyfit(lefty, leftx, 2)
            right_fit = np.polyfit(righty, rightx, 2)

            # Generate x and y values for plotting
            ploty = np.linspace(0, warped_mask.shape[0] - 1, warped_mask.shape[0])
            # create a second order poly. with "_"fit[i] being the coefficients of the poly. multiply by each y value 
            left_fitx = left_fit[0] * ploty ** 2 + left_fit[1] * ploty + left_fit[2]  
            right_fitx = right_fit[0] * ploty ** 2 + right_fit[1] * ploty + right_fit[2]


            # metric distance / pixel conversion factor
            ym_per_pix = 7.62 / 50  # cm per pixel in y dimension
            xm_per_pix = 3.5 / 80  # cm per pixel in x dimension

            # topmost y point
            y_eval = np.max(ploty)

            # RADIUS OF CURVATURE
            # Calculate the radii of curvature (see formula)
            left_curverad = ((1 + (2 * left_fit[0] * y_eval*ym_per_pix + left_fit[1]) ** 2) ** 1.5) / np.absolute(2 * left_fit[0])
            right_curverad = ((1 + (2 * right_fit[0] * y_eval*ym_per_pix + right_fit[1]) ** 2) ** 1.5) / np.absolute(2 * right_fit[0])
            curverad = (left_curverad+right_curverad)/2


            ##### YAW ANGLE #####
            # Array to store slopes
            slopes = []
            # take derivative (slope) of each line every 50 pixels in 6/10ths of the image
            for y_eval in range(0,int(np.max(ploty)*.6),50):
                left_slope =  2 * left_fit[0] * y_eval * ym_per_pix + left_fit[1]
                right_slope = 2 * right_fit[0] * y_eval * ym_per_pix + left_fit[1]
                slope = (left_slope + right_slope)/2
                slopes.append(slope)
            # average all slopes detected and find angle
            slope = np.mean(slopes)
            inv_yaw = slope
            yaw_angle = np.arctan(inv_yaw)*(180/np.pi)

	    ### UNCOMMENT BLOCK BELOW TO VIEW LIVE PLOTTING OF POLYLINES ###

            # plt.ion()
            # mark_size = 3

            # plt.xlim(0, 1280)
            # plt.ylim(0, 720)

            # plt.plot(left_fitx, ploty, color='red', linewidth=3)
            # plt.plot(right_fitx, ploty, color='green', linewidth=3)
            # plt.gca().invert_yaxis()
            # plt.pause(0.05)
            ################################################################


            # Finding Center position by averaging x values of each lane

            bottom_slice = (warped_mask[int(warped_mask.shape[0] * 9.5 / 10):warped_mask.shape[0], :])
            nonzero_slice = bottom_slice.nonzero()
            nonzerox_slice = np.array(nonzero_slice[1])
            left_line_int = np.min(nonzerox_slice)
            right_line_int = np.max(nonzerox_slice)
            position = (left_line_int + right_line_int) / 2

            offset = (int(warped_mask.shape[1]) / 2 - position) * xm_per_pix
            cv2.circle(warped_mask, (int(position), warped_mask.shape[0]), 10, 255, 3)


            # #printING TEXT
            font = cv2.FONT_HERSHEY_SIMPLEX
            out = undist_img

            text = 'Yaw Angle = {:.2f}(deg)'.format(yaw_angle)
            cv2.putText(out, text, (20, 200), font, 2, (255), 2)

            text = 'Offset = {:.2f}(cm)'.format(offset)
            cv2.putText(out, text, (20, 300), font, 2, (255), 2)

            text = 'Radius of Curvature = {:.2f}(cm)'.format(curverad)
            cv2.putText(out, text, (20, 60), font, 2, (255), 2)

            #cv2.imshow('frame', warped_mask)
            offset_arr.append(offset)
            i = i+1


            key = cv2.waitKey(5)
            settings(key, cam, runtime, mat)
        else:
            key = cv2.waitKey(5)
    cv2.destroyAllWindows()

    cam.close()
    #print("\nFINISH")


def print_camera_information(cam):
    print("Resolution: {0}, {1}.".format(round(cam.get_resolution().width, 2), cam.get_resolution().height))
    print("Camera FPS: {0}.".format(cam.get_camera_fps()))
    print("Firmware: {0}.".format(cam.get_camera_information().firmware_version))
    print("Serial number: {0}.\n".format(cam.get_camera_information().serial_number))


def print_help():
    print("Help for camera setting controls")
    print("  Increase camera settings value:     +")
    print("  Decrease camera settings value:     -")
    print("  Switch camera settings:             s")
    print("  Reset all parameters:               r")
    print("  Record a video:                     z")
    print("  Quit:                               q\n")


def settings(key, cam, runtime, mat):
    if key == 115:  # for 's' key
        switch_camera_settings()
    elif key == 43:  # for '+' key
        current_value = cam.get_camera_settings(camera_settings)
        cam.set_camera_settings(camera_settings, current_value + step_camera_settings)
        #print(str_camera_settings + ": " + str(current_value + step_camera_settings))
    elif key == 45:  # for '-' key
        current_value = cam.get_camera_settings(camera_settings)
        if current_value >= 1:
            cam.set_camera_settings(camera_settings, current_value - step_camera_settings)
            #print(str_camera_settings + ": " + str(current_value - step_camera_settings))
    elif key == 114:  # for 'r' key
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_BRIGHTNESS, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_CONTRAST, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_HUE, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_SATURATION, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_GAIN, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_EXPOSURE, -1, True)
        cam.set_camera_settings(sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_WHITEBALANCE, -1, True)
        #print("Camera settings: reset")
    elif key == 122:  # for 'z' key
        record(cam, runtime, mat)


def switch_camera_settings():
    global camera_settings
    global str_camera_settings
    if camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_BRIGHTNESS:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_CONTRAST
        str_camera_settings = "Contrast"
        #print("Camera settings: CONTRAST")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_CONTRAST:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_HUE
        str_camera_settings = "Hue"
        #print("Camera settings: HUE")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_HUE:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_SATURATION
        str_camera_settings = "Saturation"
        #print("Camera settings: SATURATION")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_SATURATION:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_GAIN
        str_camera_settings = "Gain"
        #print("Camera settings: GAIN")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_GAIN:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_EXPOSURE
        str_camera_settings = "Exposure"
        #print("Camera settings: EXPOSURE")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_EXPOSURE:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_WHITEBALANCE
        str_camera_settings = "White Balance"
        #print("Camera settings: WHITEBALANCE")
    elif camera_settings == sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_WHITEBALANCE:
        camera_settings = sl.PyCAMERA_SETTINGS.PyCAMERA_SETTINGS_BRIGHTNESS
        str_camera_settings = "Brightness"
        #print("Camera settings: BRIGHTNESS")






input_file="../livelanedet/offset.txt"
output_file="../teleOp/steering.txt"
#output_file="../teleOp/steering_ctrl.txt"

def PID(CTE):
    p=2
    i=0
    d=0
    integral=0
    derivative=0
    prevCTE=0
    integral+=CTE
    if prevCTE==0:
        prevCTE=CTE
    derivative=(CTE-prevCTE)
    prevCTE=CTE

#for resetting or limiting output
#        if abs(self.integral)>=50: #reset integral
#            self.integral=0
#        if abs(self.derivative)>CTE*.60: limit derivative
#            self.derivative=CTE*.50

    angle=-p*CTE-d*derivative-integral*i
    return angle


def follow(offset):
    prevoffset=0

    if prevoffset!=offset:

        #print(offset)
        prevoffset=offset
        steer=PID(offset)
        maxangle=37
        steering = math.floor(steer*30/maxangle+90)

        if steering>120:
            steering=120
        if steering<60:
            steering=60
        print(steering)
        F=open(output_file,"w")
        F.write('{}'.format(steering))
        F.close()
        arduino_write(steering)

def arduino_write(s):
    #if(s < 60):
     #   s = 60
    #if(s > 120):
      #  s = 120
    s = 256 - s
    arduino.write(chr(s))
    print('writing ', s, ' to arduino')

if __name__ == "__main__":
    main()
