#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char** argv)
{
 unsigned lastSpeed = 0;
 while(1)
 {
  FILE* fp = fopen("main_throttle.txt", "r");
  unsigned speed = 1;
  fscanf(fp, "%u", &speed);
  fclose(fp);
  if(lastSpeed != speed)
  {
   printf("%u\n", speed);
   lastSpeed = speed;
  }
  usleep(1000);
 }
 return 0;
}
