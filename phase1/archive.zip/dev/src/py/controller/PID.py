import math


input_file="../livelanedet/offset.txt"
output_file="../teleOp/steering.txt"
#output_file="../teleOp/steering_ctrl.txt"

class PID():
        
    def __init__(self):
        self.p=1
        self.i=0
        self.d=2
        self.integral=0
        self.derivative=0
        self.prevCTE=0
        
    def sample(self,CTE):    
        
        self.integral+=CTE
        if self.prevCTE==0:
            self.prevCTE=CTE
        self.derivative=(CTE-self.prevCTE)
        self.prevCTE=CTE
        
    #for resetting or limiting output
#        if abs(self.integral)>=50: #reset integral 
#            self.integral=0
#        if abs(self.derivative)>CTE*.60: limit derivative
#            self.derivative=CTE*.50
    
        angle=-self.p*CTE-self.d*self.derivative-self.integral*self.i
        return angle


prevfile=0
while True:
    file=open(input_file,"r")
    if prevfile!=file:
        
        deviation=float(file.readline(1))
        print(deviation)
        prevfile=deviation
        controller=PID()
        steer=controller.sample(deviation)
        maxangle=37


        steering = math.floor(steer*30/maxangle+90)
        #print(steering)
        if steering>120:
            steering=120
        if steering<90:
            steering=90
        F=open(output_file,"w")
        F.write(str(steering))





