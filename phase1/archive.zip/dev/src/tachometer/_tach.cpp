#include "../lib/main.h"
#include <vector>

static double D_CM = (4.41 * 3.14 * 2.54);

int main(int argc, char** argv)
{
 //create the sync variable for linking threads
 int RUNNING = 1;
 //create the thread with the shared sync variable
 pthread_t thread;

 //close if q is pressed
 pthread_create( &thread, NULL, checkKeyboard, &RUNNING );

 //close the gpio if it's opened, clearing the parameters
 if(FILE* pin_exists = fopen(TACHOMETER_SYSFS, "r"))
 {
  fclose(pin_exists);
  gpioUnexport(TACHOMETER);
 }

 //the values of the tachometer, edges[0] = current, edges[1] = last
 unsigned edges[2];

 //reopen the tachometer and set to INPUT
 printf("Initializing tachometer. . .\n");
 gpioExport(TACHOMETER);
 gpioSetDirection(TACHOMETER, 0);
 gpioGetValue(TACHOMETER, &edges[0]);


 //open the file to write
 FILE* fp = fopen("./files/raw_data.txt", "w");
 FILE* ft = fopen("./files/tach_data.txt","w");

 TIMER d_timer;
 initTimer(&d_timer);

 //keep track of counts when the magnet is sensed
 unsigned counts = 0;
 double rpm = 0;
 double dist = 0;
 double total_dist = 0;
 //start the global timer (for edge values)
 initTimer(&GLOBAL_TIMER);
 //start the local timer (for tachometer values)
 initTimer(&LOCAL_TIMER);

 //run until q is pressed
 while(RUNNING)
 {
  //get the last edge
  edges[1] = edges[0];

 //get the current edge
  gpioGetValue(TACHOMETER, &edges[0]);

 //if the edge changed, or timeout, print/record the value
  if(edges[0] != edges[1])
  {
   fprintf(fp, "%u %lf\n", edges[1], millis(&GLOBAL_TIMER));
   if(edges[1] == 0)
   {
    counts++;
   }
   initTimer(&GLOBAL_TIMER);
  }
  double ms = millis(&LOCAL_TIMER);
  if(counts >= 4)
  {
   rpm = (((double)counts)/ms)*60000;
   fprintf(ft, "%lf %lf\n", rpm, ms);
   printf("RPM: %lf [%u] / [took %lf s]\n", rpm, counts, ms/1000);
   initTimer(&LOCAL_TIMER);
   counts = 0;
  }
  if(ms > 2000)
  {
   rpm = 0;
   printf("RPM: 0 [%u] / [took %lf s]\n", counts, ms/1000);
   initTimer(&LOCAL_TIMER);
   counts = 0;
  }

  ms = millis(&d_timer);
  if(ms > 500 && rpm > 0)
  {
   double min = (ms / 60000);
   dist = rpm * min * 34;
   total_dist += dist;
   printf("D: %lf cm\ntotal D: %lf cm\n", dist, total_dist);
   initTimer(&d_timer);
  }

  if(total_dist > 10)
  {
   FILE* th = fopen("../py/teleOp/throttle.txt", "w");
   fprintf(th, "1000");
   fclose(th);
   usleep(3000000);
   th = fopen("../py/teleOp/throttle.txt", "w");
   fprintf(th, "1600");
   fclose(th);
  }
 }
 //close all resources
 fclose(fp);
 fclose(ft);
 RUNNING = 0;
 gpioUnexport(TACHOMETER);

 //exit the thread
 pthread_exit(NULL);
}

//TO-DO: begin undefining macros...
#undef GETTING_EDGES_OR_TIMING_OUT

