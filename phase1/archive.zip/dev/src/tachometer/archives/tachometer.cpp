#include "tachometer.h"

int main(int argc, char** argv)
{
 int RUNNING = 1;
 pthread_t thread;
 pthread_create(&thread, NULL, checkKeyboard, &RUNNING);

 int __COUNTS__ = 0;
 if(argc >= 1)
	 __COUNTS__ = atoi(argv[1]);
 int __SPEED__ = 0;
 if(argc >= 2)
	 __SPEED__ = atoi(argv[2]);
 int __ITERATION__ = 0;
 if(argc >= 3)
	 __ITERATION__ = atoi(argv[3]);
// printf("This iteration's\nCounts=%d\nSpeed=%d\n", __COUNTS__, __SPEED__);
 if(FILE* pin_exists = fopen(SYS_FS_LOCATION, "r"))
 {
  fclose(pin_exists);

  gpioUnexport(TACHOMETER);
 }

 gpioExport(TACHOMETER);
 gpioSetDirection(TACHOMETER, 0);
 unsigned edges[2];
 gpioGetValue(TACHOMETER, &edges[0]);
 edges[1] = edges[0];

 initTimer(&GLOBAL_TIMER);
// char buffers[3][128];
// sprintf(buffers[0], "files/tachs_iter_%d_counts_%d_speed_%d.txt", __ITERATION__, __COUNTS__, __SPEED__);
// sprintf(buffers[1], "files/times_iter_%d_counts_%d_speed_%d.txt",__ITERATION__, __COUNTS__,  __SPEED__);

// printf("Tachometer started %s\nFiles:\n\'%s\'\n\'%s\'\n", (edges[0] == 0 ? "LOW" : "HIGH"), buffers[0], buffers[1]);
// FILE* tachs = fopen(buffers[0], "w");
// FILE* times = fopen(buffers[1], "w");

 //get the first rotation
 char buffer[128];
 sprintf(buffer, "files/tachs_iter_%d_speed_%d_counts_%d.txt", __ITERATION__, __SPEED__, __COUNTS__);
 FILE* tachs = fopen(buffer, "w");
 double rpm = 0;
 while(RUNNING)
 {
  unsigned counts = 0;

  initTimer(&LOCAL_TIMER);
  double local_time = millis(&LOCAL_TIMER);
  while(RUNNING && counts < 2 * __COUNTS__ && local_time < 1000)
  {
     while(RUNNING && counts < 2 * __COUNTS__ && local_time < 1000 && edges[0] == edges[1])
     {
 	gpioGetValue(TACHOMETER, &edges[0]);
        local_time = millis(&LOCAL_TIMER);
     }
     counts++;
     edges[1] = edges[0];
  }

  if(counts == 2 * __COUNTS__)
  {
   rpm = 60000.0 * __COUNTS__ / local_time;
   printf("rpm: %lf\n", rpm);
  } else {
   printf("rpm: 0\n");
  }
  fprintf(tachs, "%lf %lf\n", rpm, local_time);
 }
 fclose(tachs);

// fclose(tachs);
// fclose(times);
 gpioUnexport(TACHOMETER);

 pthread_exit(NULL);
}
