#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <time.h>
#include <sys/time.h>
#include <iostream>
#include <string>
#include <unistd.h>
#include <pthread.h>
#include "../lib/jetsonTX2.h"

#define TIMER struct timeval
TIMER begin, end;
TIMER GLOBAL_TIMER, LOCAL_TIMER, TIMEOUT[10];

void initTimer(struct timeval* timer)
{
 gettimeofday(timer, NULL);
}
double millis(struct timeval* timer)
{
 gettimeofday(&end, NULL);
 double seconds = end.tv_sec - timer->tv_sec;
 double useconds = end.tv_usec - timer->tv_usec;
 double mseconds = ((seconds * 1000) + (useconds / 1000));

 return mseconds;
}

void* checkKeyboard(void* args)
{
 int* RUNNING = (int*)args;

 while(*RUNNING)
 {
  char c;
  scanf("%c", &c);
  *RUNNING = c == 'q' || c == '0' ? 0 : 1;
 }

 pthread_exit(NULL);
}

#define TACHOMETER pin13
#define SYS_FS_LOCATION "/sys/class/gpio/gpio397/value"
