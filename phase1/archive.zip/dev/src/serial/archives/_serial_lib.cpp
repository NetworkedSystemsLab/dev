
#include "_serial.h"

//SerialData class implementation
SerialData::SerialData( int s, int isRunning ): serial( s ), RUNNING( isRunning ) 
{
 //FILE* f_t = fopen(THROTTLE_FILE, "w");
// FILE* f_s = fopen(STEERING_FILE, "w");
 //fprintf(f_t, "1600");
 //fprintf(f_s, "90");
 //fclose(f_t);
 //fclose(f_s);
}

//update the serial buffer if there was a change
int SerialData::update()
{
 FILE* f_t = fopen(THROTTLE_FILE, "r");
 FILE* f_s = fopen(STEERING_FILE, "r");
 fscanf(f_t, "%d", &throttle);
 fscanf(f_s, "%d", &steering);
 printf("[%d %d]\n", throttle, steering);
 fclose(f_t);
 fclose(f_s);
 static int last_t = 0, last_s = 0;
// if(last_t == throttle && last_s == steering) return 0;

 last_t = throttle;
 last_s = steering;
 send();
 return 1;
}

//send the data over serial
void SerialData::send()
{
 char t = (char)((throttle - 1000) / 10);
// char s = -(char)steering; fprint(t, s); //added by eduardo

 write( serial, &throttle, 1 );
 write( serial, &steering, 1 );
}


//Thread class
Thread::Thread( void* (*cb)(void*), void* data, bool launchNow ): callback(cb), args(data)
{
 if(launchNow)
  launch();
}

//launch the thread
void Thread::launch()
{
 pthread_create( &thread, NULL, callback, args );
}

//close the current thread
void Thread::close()
{
 pthread_exit( NULL );
}



//general function implementations
int open_port()
{
 //try opening ACM0
 int fd = open( ACM0, O_RDWR | O_NOCTTY | O_NDELAY );
 if( fd == -1 )
 {
  //try opening ACM1
  printf("Unable to open %s. Trying %s\n", ACM0, ACM1);

  fd = open( ACM1, O_RDWR | O_NOCTTY | O_NDELAY );

  //can't open either. exit.
  if( fd == -1 )
  {
   printf("Unable to open %s either.\nGo home\n\t-Behrad\n", ACM1);
   //force quit
   exit( -1 );
  } else {
   printf("Port is open on %s.\n", ACM1);
  }
 } else {
  printf("Port is open on %s.\n", ACM0);
 }

 //set and return the port
 fcntl( fd, F_SETFL, 0 );
 fd = configure_port( fd );
 return fd;
}


int configure_port(int fd)
{
 struct termios tty, ttyOld;
 memset( &tty, 0, sizeof tty );

 if( tcgetattr( fd, &tty ) != 0 )
 {
  printf("Error %d from tcgetattr: %s\n", errno, strerror(errno));
 }

 ttyOld = tty;
 cfsetospeed( &tty, B9600 );
 cfsetispeed( &tty, B9600 );

 #define ttynand( setting ) tty.c_cflag &= ~setting
 #define ttyor( setting ) tty.c_cflag |= setting

 ttynand( PARENB ); //make 8n1
 ttynand( CSTOPB );
 ttynand( CSIZE );
 ttyor( CS8 );

 ttynand( CRTSCTS ); //no flow control
 tty.c_cc[ VMIN ] = 1; //read doesn't block
 tty.c_cc[ VTIME ] = 5; //0.5 second read timeout
 ttyor( CREAD | CLOCAL );

 cfmakeraw( &tty );

 tcflush( fd, TCIFLUSH ); //flush port
 if( tcsetattr( fd, TCSANOW, &tty ) != 0 )
 {
  printf("Error %d from tcsetattr: %s\n", errno, strerror(errno));
 }

 #undef ttynand
 #undef ttyor
 return fd;
}





